# Would Company CI be relatively resilient if demand weakened after the anchor (2021-12)?

**Short answer: Yes.** Based on the pre-anchor evidence, Company CI would be expected to be relatively resilient to a demand downturn — its revenue is cyclical, but its profitability has historically held up and even improved through downturns, supported by dominant market positions.

## 1. Market leadership supports pricing power and volume defense
Exhibit 1 (Company CI as of 2021) shows Company CI holding the #1 share in every disclosed segment:
- Residential HVAC: ~70% share (next competitor, LG, ~13%)
- Product F: ~35% share, largest of seven players
- Refrigeration: ~40% share, twice the next competitor
- Transport: ~40% share, twice the next competitor (Company Z ~20%)

Such leadership in HVACR/thermal-management niches typically confers pricing power, distribution strength, and specification incumbency, which cushion both volume and margin when demand softens.

## 2. Demonstrated margin defense in prior downturns (Exhibit 2)
The 2007A–2021A financial history is the strongest evidence:
- **2009 (GFC):** Revenue fell -15.3%, yet gross margin *rose* from 28.4% to 29.7% and Adj. EBITDA margin *expanded* from 21.5% to 22.3%. Adj. EBITDA fell only -12.2%, then rebounded +39.5% in 2010.
- **2020 (COVID):** Revenue fell -7.6%, but gross margin actually improved to 34.9% (from 33.9%) and Adj. EBITDA margin held at 25.3% (vs. 24.8%); EBITDA declined just -5.9%.
- Management demonstrably flexes costs to protect margins when volumes drop — earnings declines are far milder than revenue declines.

## 3. Structural improvement through cycles
Over 2007–2021, gross margin rose from ~28% to a sustained ~33–35% band, and Adj. EBITDA margin from ~21% to a sustained ~24–27% band, including through multiple downturns. Revenue recovered quickly after each decline (2010: +18.6%; 2021: +18.7% to a record $4,460M). This is the profile of a business whose economics are not broken by demand shocks.

## 4. Experienced leadership
The leadership source describes a global team with 375 years of combined experience leading public, industrial, and HVACR companies — consistent with the demonstrated ability to manage through cycles.

## 5. Macro/financing backdrop at the anchor
At 2021-12, conditions were benign: PCE inflation was low (1.1% in 2021, Exhibit 6) and the U.S. leveraged loan market was at/near record issuance ($184B institutional volume in 1Q21, Exhibit 9), supporting the carve-out financing and refinancing flexibility.

## Caveats / what would limit resilience
- Revenue *is* cyclical: five down years out of fifteen, including a -15% decline in 2009, so top-line weakness should be expected in a downturn.
- A PE carve-out (Company ED context in the timeline) typically adds leverage, which amplifies equity risk even if operating performance is resilient.
- The pre-anchor materials do not disclose demand mix detail (e.g., replacement vs. new construction), so the degree of volume defensiveness cannot be confirmed directly; the conclusion rests on demonstrated historical performance and market position.

**Conclusion:** Expect modest-to-moderate revenue declines in a demand downturn, but with margins and EBITDA holding up substantially better than revenue — as they did in both 2009 and 2020 — making Company CI relatively resilient among industrial peers.
