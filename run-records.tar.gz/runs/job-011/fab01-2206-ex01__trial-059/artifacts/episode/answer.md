# Why Company CI's recent margin pressure mattered for the investment case (as of 2022-06)

## What the margin data showed
Company CI's profitability had eroded from its peak going into the anchor. Adjusted EBITDA margin fell from 27.3% in 2017 to 26.0% in 2018, 24.8% in 2019, 25.3% in 2020, and 24.4% in 2021 — roughly 290 bps off the 2017 peak (Exhibit 2). Gross margin likewise compressed from 37.1% in 2017 to 33.2% in 2021. Yet demand was clearly not the problem: revenue rebounded 18.7% in 2021 to $4,460 million, the highest level in the company's history, and Adj. EBITDA grew 14.7% to $1,090 million.

## Why it happened — and why that was the crux
Per the case materials (quoted in Exhibit 2), the margin decline over the prior two years was primarily due to long-term contracts with original equipment manufacturers (OEMs) that included infrequent price adjustment terms. In other words, Company CI was locked into stale pricing while its input costs moved — a contract-structural issue, not evidence of lost competitiveness. Exhibit 1 shows Company CI held #1 market positions (roughly 70% share in Residential HVAC, 40% in Refrigeration, 40% in Transport, and 35% in Product F, the largest single position), which supported the view that the company had real pricing power it simply had not yet been able to exercise.

## Investment significance for Company ED at the anchor
1. **It defined the core underwriting question — cyclical or structural?** If the compression was structural (permanent loss of pricing power), the business was worth materially less. If it reflected contract mechanics, margins should recover as the long-term OEM agreements rolled off and were repriced. The OEM-contract explanation, combined with intact market leadership and record 2021 revenue, pointed to a fixable pricing problem rather than franchise decay — the classic setup for a carve-out buyer.

2. **It was the main value-creation lever.** With revenue already at a record and share positions dominant, there was limited need to bet on top-line growth. The thesis instead hinged on margin recovery toward the ~27% EBITDA margins demonstrated in 2017–2018 through repricing as contracts reset — upside that an owner could underwrite without assuming market-share gains.

3. **It shaped entry valuation.** Two years of declining margins made Company CI look weaker than its franchise quality justified, potentially allowing Company ED to acquire the business at a price reflecting trough-era profitability while underwriting normalized margins.

4. **It made inflation pass-through the key diligence risk at 2022-06.** With inflation elevated (PCE inflation data, Exhibit 6, and a Federal Reserve that raised rates 75 bps in June 2022), the exact contract flaw that caused the pressure — infrequent price adjustment terms — was maximally exposed to a rising-cost environment. Underwriting required confidence that repricing could outpace input-cost inflation, and that the timing of contract resets would deliver recovery before financing costs (rising with Fed tightening) eroded deal returns.

In short, the recent margin pressure mattered because it was simultaneously the deal's principal risk (if structural or if repricing lagged inflation) and its principal opportunity (if contractual and reversible), making the diagnosis of the margin decline the pivotal judgment in Company ED's carve-out investment case at the anchor.
