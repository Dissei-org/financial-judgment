# Is Company CI's $14 Billion Entry Price Attractive vs. Public HVAC Comparables?

**View: Yes — the $14 billion entry price is attractive.** On a like-for-like pro forma basis, the deal prices Company CI at a meaningful discount to publicly traded HVAC OEMs, despite Company CI bringing superior market positions and superior historical revenue growth. Even on an unadjusted basis, the price is at or below where the public HVAC peer group trades, and well below its own 5- and 10-year average trading multiples.

## The Multiples Evidence (Exhibit 8, centered on FYE 9/30/22 at the $14bn price)

**EV / EBITDA — the headline comparison:**
- Company CI at $14bn: **12.4x LTM / 13.4x NTM** unadjusted; **10.4x LTM / 11.3x NTM on a pro forma (PF) basis** (i.e., after carve-out/standalone adjustments validated in diligence).
- Public HVAC OEMs average: **12.9x LTM / 13.2x NTM** currently; **14.4x NTM 5-yr average**; **13.5x NTM 10-yr average**.
- Comparable-margin industrials are even richer (19.0x LTM, 15.3x NTM), underscoring that quality industrial assets carry premium multiples.

So on a pro forma basis Company ED is paying roughly a **~20% discount on LTM EBITDA (10.4x vs. 12.9x)** and a **~14% discount on NTM EBITDA (11.3x vs. 13.2x)** to the average public HVAC manufacturer. Against the peer group's own historical averages (14.4x 5-yr NTM), the discount is even larger (~21%). The unadjusted multiples (12.4x LTM / 13.4x NTM) are still at-or-below current peer trading levels — a rarity for a control acquisition of a market-leading franchise, which would normally command a control premium to public trading prices.

The same pattern holds on **EV / EBIT**: CI at 11.9x PF LTM and 13.0x PF NTM vs. HVAC OEMs at 16.2x LTM / 15.2x NTM — a discount of roughly 15–26%.

## Why the Discount Is Not Merited by Fundamentals — Quality Supports the Price

1. **Dominant market positions (Exhibit 1).** As of 2021, Company CI holds ~70% share in Residential HVAC, ~40% in Refrigeration, ~40% in Transport, and is the single largest player in Product F (~35%). This is a market leader, not a marginal asset, and leaders normally trade at a premium.
2. **Superior top-line growth.** CI's 5-yr historical revenue growth of **5.2%** is more than double the HVAC OEM average of **2.1%** (Exhibit 8). 2021 revenue grew 18.7% and 2022E a further 13.4% to ~$5.06bn (Exhibit 2).
3. **Scale and profitability.** CI generated ~$1,175mm Adj. EBITDA in 2022E at a 23.2% margin, with EBITDA margins in the 21–27% band for 15 years, including through the 2008–09 downturn (revenue fell 15.3% in 2009 but EBITDA margin held at 22.3%) — evidence of resilience.

## The Honest Counterweights — Why the Discount Exists but Is Acceptable

- **Softer forward EBITDA growth:** CI's 2-yr forward EBITDA growth of 3.3% trails the OEM average of 7.2%, and its 5-yr historical EBITDA growth (1.9%) lags peers (8.4%) — EBITDA has been roughly flat since 2017 (~$1,072mm) while revenue grew, i.e., **margin compression from 27.3% (2017) to 23.2% (2022E)**.
- **Carve-out risk:** standalone costs and dis-synergies are real — but diligence (Exhibit 4) shows these were bottom-up validated, with TSAs in place, an identified cost-savings target, and lockbox mechanics accruing sign-to-close cash flow to CI. The PF multiples already capture these adjustments.
- **Macro/financing backdrop:** as of September 2022 the Fed had just delivered 75bp hikes (June and July 2022), credit was tightening versus the record 2021 leveraged-loan market, and recession risk was rising. That argues for discipline — and it is also precisely why a seller (Company BR, amid a CEO transition) is willing to transact at a discounted multiple and to roll $1.70bn of common equity (40%) plus a $2.25bn 5% PIK seller note, signaling seller confidence and sharing the risk.

## Conclusion

**The $14 billion entry price is attractive relative to public HVAC comparables.** Measured against how public equity markets value comparable HVAC manufacturers, Company ED is buying the market leader — with double the peers' historical revenue growth and resilient ~23%+ EBITDA margins — at 10.4x PF LTM / 11.3x PF NTM EBITDA versus 12.9x / 13.2x for the average public HVAC OEM, and at an even wider discount to the peers' 5- and 10-year average multiples. The discount more than compensates for CI's margin-compression and slower forward EBITDA-growth profile, especially given the validated cost-savings opportunity, the de-risked carve-out, and seller alignment via retained equity and a PIK note. On the evidence available as of September 2022, the deal-table price represents buying a best-in-class asset at a below-market multiple.
