# Segment-Share Exhibit: Implication for Company CI's Relative Market Position

## Bottom line
The segment-share exhibit (Exhibit 1, "Company CI (as of 2021)", sourced from Company documents) implies that **Company CI is the market leader — the #1 player by share — in every one of the four end-market segments in which it operates**. Its lead ranges from an outright monopoly-like position in Residential HVAC to a clear plurality roughly 2x the size of the next competitor in Refrigeration and Transport.

## Evidence from the exhibit
Reading the stacked segment bars (each bar sums to 100% of the segment market):

| Segment | Company CI share | Next-largest competitor(s) | Implied position |
|---|---|---|---|
| Residential HVAC | ~70% (0-70) | LG ~13% (70-83), Rechi ~2% (83-85), Other ~15% | Dominant #1; ~5x the nearest rival |
| Product F | ~35% (0-35) | Company EN ~5%, Company EU ~7%, Company FA ~6%, Company J ~9%, Other Captive ~10%, Other ~28% | #1; ~3.5x the largest single rival; fragmented field |
| Refrigeration | ~40% (0-40) | Company EN ~10%, Company EV ~10%, Company BE ~10%, Other ~30% | #1; ~4x any single rival |
| Transport | ~40% (0-40) | Company Z ~20%, Company J ~10%, Other ~30% | #1; ~2x the nearest rival |

## Defensible inference
1. **Leadership, not participation.** In all four segments Company CI occupies the first (largest) slice of the bar. No competitor surpasses it anywhere — the implication is a portfolio of leading franchises, not a challenger business.
2. **Dominance where it matters most.** The ~70% Residential HVAC share points to entrenched scale, distribution, or brand advantages that smaller rivals (LG at ~13%, Rechi at ~2%) cannot realistically contest near-term. Such a position typically confers pricing power and margin resilience.
3. **Fragmented competition elsewhere reinforces the moat.** In Product F and Refrigeration the remaining share is split among many small players (~5-10% each) plus captives; no consolidated threat exists. In Transport, Company Z (~20%) is the only credible challenger, and Company CI still doubles its share.
4. **Corroboration from financials.** Exhibit 2 ("Company CI (million USD)") is consistent with a share leader: $4.46B of 2021 revenue, ~33% gross margins and ~24% Adj. EBITDA margins sustained over a decade-plus — economics typical of a #1 player with scale advantages rather than a marginal participant.
5. **Deal relevance (as of 2022-06).** In the carve-out context (Company BR's CEO retirement in 2021 catalyzing discussions, per the pre-anchor timeline), the exhibit supports underwriting Company CI as a market-leading, defensible platform asset — the kind of business a sponsor such as Company ED could justify a premium for, with the caveat that the ~70% Residential HVAC share also concentrates antitrust/growth-runway scrutiny on that segment.

## Caveats
- Shares are as of 2021 and self-reported from Company documents; segment definitions (e.g., "Other Captive" in Product F) may flatter CI's relative standing.
- Leadership in share does not by itself prove growth: Exhibit 2 shows cyclicality (e.g., 2009 and 2020 revenue declines), so the position is strong but not immune to end-market cycles.
- I reason strictly as of 2022-06; no post-anchor events are relied upon.
