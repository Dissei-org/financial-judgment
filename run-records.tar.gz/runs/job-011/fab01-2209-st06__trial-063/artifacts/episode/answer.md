# Gating Diligence Workstream for Company ED at the September 2022 Signing of the Company CI Carve-Out

## Answer

Company ED should treat the **financing / debt-capital-markets workstream** — securing committed third-party debt on workable terms and validating that the capital structure is actually executable in the September 2022 credit market — as the gating diligence workstream before signing the Company CI carve-out. All other workstreams should be treated as necessary inputs to that decision, but none of them should control go/no-go.

## Why the financing workstream is gating

1. **Every other workstream is already de-risked and complete.** Exhibit 4 (technical diligence) shows all six operational workstreams closed out before the September 2022 deal-table meeting:
   - Finance/Accounting: detailed diligence complete; modest QoE (CoE) adjustment; lockbox mechanics finalized so sign-to-close cash flow accrues to the carve-out.
   - Tax: diligence completed; go-forward structure co-developed with management.
   - HR: pension, union/labor, executive comp review completed.
   - Operations: multi-month Company EJ/Company ED study complete; cost-savings target identified (feeding the $148mm cost-savings leg of the 2022–2027 EBITDA bridge, Exhibit 5).
   - IT & Cyber: complete (PwC).
   - Carve-Out: bottoms-up validation of management standalone-cost assumptions done; personnel identified; TSAs well in place with a stand-up roadmap. The standalone-cost burden ($41mm incremental standalone costs/QoE adjustments burdening Adj. EBITDA per Exhibit 3; -$6mm standalone costs in the Exhibit 5 bridge) is already quantified and priced into the model.

   None of these can be "gating" because their answers are known and reflected in the deal economics.

2. **The credit market is the live, unresolved, deal-threatening variable.** The deal requires $5.5 billion of third-party debt against a $14 billion purchase price (Exhibit 10 Sources & Uses), structured at roughly 4.0x leverage with SOFR-linked floating coupons (Term Loan A at SOFR+4.50% stepping up, Direct Loan at SOFR+6.75%, Table 1). But the market for that debt is collapsing precisely as Company ED sits at the deal table:
   - U.S. leveraged loan issuance by non-bank institutional lenders fell from $184B in 1Q21 to $112B in 1Q22, $56B in 2Q22, and just **$22B in 3Q22** (Exhibit 9) — the "severe scarcity of high-yield debt capital" the case materials describe.
   - The Federal Reserve raised rates 75 bps in both June and July 2022 and delivered another supersized hike in September 2022 (timeline; Sources 4 and 5), pushing 30-day SOFR to 2.42% by 9/30/2022 and directly raising the cash interest burden on the floating-rate structure.

3. **Financing failure is the one risk that can kill the deal at or after signing.** If committed debt cannot be obtained at the assumed spreads/OIDs (97.5 / 96.6 OID) and covenant levels (1st Lien Net Leverage < 6.5x EBITDA), Company ED faces either a failed signing, a punitive re-trade, or an over-levered capital structure whose interest costs erode the projected EBITDA growth (2022 EBITDA $1,130mm to 2027E $1,614mm, Exhibit 5). An operational diligence miss is manageable post-close; a financing hole at $5.5B of third-party debt is not.

4. **The deal's mitigants confirm financing is the binding constraint.** The structure itself — a $2.25B Company BR seller note, convertible preferred, a 60/40 common split with the seller retaining 40% via Company BK, and the sign-to-close lockbox cash benefit (-$310mm) — exists precisely to shrink the third-party debt check and mitigate the scarcity of debt capital. These structural workarounds are evidence that the financing question, not any operational question, is what the signing decision hinges on.

## Practical implication

Before signing, Company ED should require hard, committed financing (signed commitment papers for the Term Loan A and Direct Loan at tested pricing, OID, and covenant terms, with the seller note and co-invest equity locked) as the explicit go/no-go condition. Carve-out/standalone-cost diligence — already complete — remains the critical *supporting* input because it sets the true Adjusted EBITDA against which ~4.0x leverage and the 6.5x covenant are measured, but it is the financing workstream that should control whether Company ED signs in September 2022.
