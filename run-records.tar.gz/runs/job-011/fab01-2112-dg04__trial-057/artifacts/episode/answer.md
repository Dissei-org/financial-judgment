# Diagnosis of Company CI's Recent Margin Pressure (as of 2021-12)

## The fact pattern (Exhibit 2)
Company CI's margin pressure is real but is a *cost-side / structural* problem, not a demand or market-share problem:

- **Gross margin** peaked at 37.1% in 2017 and has compressed ~390 bps to 33.2% in 2021 (35.1% in 2018, 33.9% in 2019, a 34.9% uptick in 2020, then a sharp 170 bps drop in 2021).
- **Adj. EBITDA margin** fell from a 27.3% peak in 2017 to 24.4% in 2021 — its lowest level since 2013 — even though 2021 Adj. EBITDA grew +14.7% to $1,090M.
- **Revenue is not the issue**: 2021 revenue rebounded +18.7% to a record $4,460M, well above the prior 2018 peak of $4,182M.

## Diagnosis
1. **Multi-year structural drift from the 2017 profitability peak.** Margin erosion began well before COVID (2018–2019: gross margin 37.1% -> 33.9%; EBITDA margin 27.3% -> 24.8%), indicating deteriorating price/mix and cost discipline while the top line was roughly flat.

2. **A COVID volume shock in 2020 with negative operating leverage.** Revenue fell -7.6% and Adj. EBITDA fell -5.9%; the modest gross-margin uptick to 34.9% was likely mix/cost-actions masking fixed-cost deleverage, and EBITDA margin stayed depressed at 25.3%.

3. **2021: price/cost squeeze during the rebound.** The most telling signal is that record 2021 revenue came with *falling* margins (gross -170 bps, EBITDA -90 bps). That combination points to rising input, component, and logistics costs that pricing has not yet recaptured — a classic price/cost lag in a demand surge — rather than weak demand.

## What the pressure is NOT
- **Not share loss**: Exhibit 1 shows CI with dominant positions at the anchor (~70% of residential HVAC compressors; ~35–40% shares in Product F, refrigeration, and transport), so volume-based competitive displacement is not the driver.
- **Not broad consumer-price inflation**: Exhibit 6 shows PCE inflation of just 1.4% (2020) and 1.1% (2021) in the case data, so the squeeze is specific to CI's input costs and pricing, not a general inflation environment.

## Bottom line for the carve-out case
At the 2021-12 anchor, CI's margin pressure should be diagnosed as a cyclical price/cost lag layered on top of a four-year structural erosion from an unsustainably high 2017 margin peak. The encouraging elements are record 2021 revenue, intact dominant market shares, and EBITDA already recovering in absolute dollars — suggesting the margin gap to the ~27% EBITDA-margin peak is potentially addressable through pricing actions and cost/operational improvement under new ownership, which is precisely the value-creation thesis a PE sponsor (e.g., Company ED) would underwrite. The risk is that part of the compression is secular (mix, OEM customer pricing power), so underwriters should not assume a full mechanical return to 2016–2017 peak margins.
