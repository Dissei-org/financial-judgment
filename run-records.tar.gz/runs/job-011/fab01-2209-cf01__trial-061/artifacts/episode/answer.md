# Counterfactual: Company BR Declines the Rollover and Seller Note (as of 2022-09)

## 1. The hole in the capital structure

Under the proposed structure for the Company CI carve-out (Exhibits 10 and table_1), the $14.05BN of sources funding the ~$14.0BN purchase price (plus $362M of fees, less $310M of sign-to-close cash) was:

- **Third-party senior debt: $5.5BN** (~4.0x leverage) — $2.9BN Term Loan A (SOFR+4.50%, 97.5 OID) + $2.6BN Direct Loan (SOFR+6.75%, 96.6 OID), with a 1st Lien Net Leverage covenant < 6.5x EBITDA
- **Seller note from Company BR: $2.25BN** (5% PIK, senior to the preferred)
- **Convertible preferred from Company ED + co-invest: $2.0BN** (7% PIK, converts at a 10% premium)
- **Common equity: $2.55BN from Company ED/co-invest (60%) + $1.70BN from Company BR (40%)**
- Company BR also contributes **$50M of balance-sheet cash**

If BR declines to roll equity and to provide the seller note, the funding gap is **$2.25BN + $1.70BN = $3.95BN — roughly 28% of total sources** (plus the lost $50M of cash). To close at the same $14BN price, Company ED must replace that $3.95BN dollar-for-dollar.

## 2. Why the gap cannot be filled with more third-party debt

- **Covenant math.** The senior debt is already ~4.0x on the deal's projected EBITDA basis (2025E post-cost-initiative Adj. EBITDA of ~$1,378M, Exhibit 3), i.e., ~4.7x on 2022E EBITDA of $1,175M and ~5.0x on 2021A EBITDA of $1,090M (Exhibit 2). Adding $3.95BN of debt would take total debt to ~$9.45BN — roughly **8.0x 2022E EBITDA and ~9.0x 2023E EBITDA ($1,046M)** — far above the **6.5x 1st Lien Net Leverage covenant** and any plausible September-2022 underwriting standard. Even maxing out covenant headroom would add at most ~$1–1.5BN of debt capacity, and only at punitive terms.
- **Market reality at the anchor.** 30-day SOFR was already 2.42% (9/30/2022) after 75bp hikes in June and July, with another supersized hike in September 2022 and more expected (Sources 4, 5). U.S. leveraged-loan issuance had collapsed — institutional volume fell from $184BN in 1Q21 to just **$22BN in 3Q22** (Exhibit 9). The existing tranches already required deep OIDs (97.5 / 96.6) and wide spreads (SOFR+4.50% stepping up / SOFR+6.75%). Incremental junior debt to replace a 5% PIK seller note would be dramatically more expensive than 5% PIK — if it could be placed at all.

## 3. How ED would have to reshape the structure

With debt capacity effectively capped, ED would have to fill nearly the entire $3.95BN with **its own equity and co-invest equity**:

- **Equity check nearly doubles.** ED/co-invest contributions would rise from $4.55BN ($2.0BN preferred + $2.55BN common) to roughly **$8.5BN** (~60% of total sources), taking common ownership from 60% to **100%**.
- **Likely mechanics:** (a) upsize the common check by ~$1.7BN to replace BR's rollover; (b) replace the $2.25BN seller note with an ED-funded instrument mimicking it — e.g., a larger 7% PIK convertible preferred or a holdco PIK note sitting where the seller note sat (senior to preferred) — which preserves senior-leverage optics but is still economically ED's money; and/or (c) syndicate much more co-invest to other LPs, because a ~$8.5BN single-deal exposure would be an outsized concentration even for the $26.2BN Product X fund (roughly a third of the fund in one asset), pushing against diversification limits.
- **Any residual debt** could only be added up to the 6.5x covenant, likely as more direct-lending debt at wider spreads and deeper OID than the existing SOFR+6.75% / 96.6 OID loan, raising cash interest burden on a business whose 2023E EBITDA ($1,046M) is projected to dip before recovering.
- ED would also need to replace the **$50M of balance-sheet cash** BR was to provide, and it would lose the seller's implicit support; to hold the $14BN price, ED absorbs all of this rather than re-trading the deal.

## 4. How risk-sharing shifts

**Under the proposed structure, BR shares risk three ways:** (i) the $1.7BN rollover keeps 40% of the equity downside (and upside) with the seller; (ii) the $2.25BN 5% PIK seller note makes BR a creditor of its own divested business — deferred, subordinated-to-senior-debt consideration whose repayment depends on the carve-out succeeding; and (iii) the rollover signals BR's confidence in the $14BN valuation, validating the price and aligning incentives through the transition.

**If BR declines:**

- **BR converts to a clean, all-cash exit at close.** All $14BN of value risk, financing risk, and execution/stand-up risk (the carve-out already carries ~$41M of incremental standalone costs and ~$80–100M/yr of one-time expenses, Exhibit 3) transfers entirely to ED and its co-investors. BR bears no risk that the business underperforms the price ED paid.
- **ED's downside exposure roughly doubles** — from $4.55BN to ~$8.5BN of equity at risk — while its upside ownership rises from 60% to 100%. The PIK preferred/note replacement means ED pays the 'deferred' portion of the price to itself, so there is no true deferral of consideration risk; it is fully funded at close.
- **Loss of seller validation and alignment.** Without BR's 40% rollover, ED loses both the price-signaling comfort of a sophisticated seller keeping skin in the game and BR's ongoing interest in a smooth separation; governance becomes 100% ED, simplifying control but removing a aligned partner.
- **Terms like the preferred's priority sell-down after an IPO** (designed to let ED exit ahead of BR's rolled stake) become moot against BR, and ED would likely seek compensating protections — bigger OID/fees, tighter seller reps/indemnities, or an earnout — but to close **at the same price**, ED must simply absorb the risk BR was previously carrying.

**Bottom line:** Without BR's rollover and seller note, ED cannot re-lever the deal — the 6.5x covenant and the frozen September-2022 loan market foreclose that. It would have to nearly double its equity/co-invest check to ~$8.5BN (likely via a larger common stake to 100% ownership plus an upsized PIK preferred or holdco note standing in the seller note's place, with heavier LP co-invest to manage fund concentration). Risk-sharing shifts decisively: BR moves from partner-creditor with $3.95BN still exposed to a fully cashed-out seller, while ED consolidates 100% of the upside, the downside, and the execution risk of the carve-out.
