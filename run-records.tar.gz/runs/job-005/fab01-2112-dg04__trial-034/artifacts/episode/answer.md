# Diagnosis of Company CI's Recent Margin Pressure (as of 2021-12)

### Executive Summary
As of the December 2021 anchor, Company CI's recent margin compression should be diagnosed as a **temporary, contractual pricing lag** rather than a structural deterioration of its competitive moat or secular loss of pricing power. While revenue rebounded strongly in 2021 (+18.7% YoY to $4,460M) and Adjusted EBITDA reached $1,090M (+14.7% YoY), percentage margins compressed primarily due to **long-term contracts with original equipment manufacturers (OEMs) that feature infrequent price adjustment terms**. Backed by dominant market share across all major product lines (including ~70% in Residential HVAC and ~35-40% across Product F, Refrigeration, and Transport), Company CI maintains robust fundamental pricing power and is well-positioned to restore margins as contracts reach scheduled reset windows.

---

### 1. Financial Profile and Magnitude of Margin Compression

Company CI's historical financials (Exhibit 2) reveal the following margin trends:

* **Gross Margin Compression:**
  * **2021A:** Gross profit was $1,483M on $4,460M revenue, translating to a **33.2% gross margin**.
  * **YoY Compression:** Gross margin fell **170 basis points** from 34.9% in 2020A ($1,310M gross profit on $3,758M revenue).
  * **Multi-Year Trend:** Gross margin peaked at **37.1% in 2017A**, before drifting downward through 35.1% (2018A), 33.9% (2019A), 34.9% (2020A), and 33.2% (2021A), representing a cumulative compression of ~390 bps from peak levels.

* **Adjusted EBITDA Margin Compression:**
  * **2021A:** Adjusted EBITDA reached $1,090M, representing an **Adjusted EBITDA margin of 24.4%**.
  * **YoY Compression:** Adjusted EBITDA margin declined **90 basis points** from 25.3% in 2020A ($950M Adj. EBITDA).
  * **Multi-Year Trend:** Adjusted EBITDA margin peaked at **27.3% in 2017A**, declining to 26.0% (2018A), 24.8% (2019A), 25.3% (2020A), and 24.4% (2021A), a cumulative compression of ~290 bps from peak levels.

* **Revenue vs. Profit Growth Mismatch:**
  * Revenue expanded rapidly in 2021A (+18.7% YoY), indicating robust volume demand across end markets.
  * However, gross profit (+13.2%) and Adjusted EBITDA (+14.7%) grew at a slower rate than revenue, resulting in margin dilution across both metrics.

---

### 2. Core Root Cause: OEM Contractual Reset Mechanisms

* **Infrequent Contractual Price Adjustments:**
  The dataroom evidence (Exhibit 2 case quote) explicitly identifies the primary cause: *"Although Company CI margins declined over the past two years, this was primarily due to longterm contracts with original equipment manufacturers (OEMs) that included infrequent price adjustment terms."*

* **Inflation and Cost Pass-Through Lag:**
  In an inflationary environment with rising raw material, freight, and supply-chain costs, long-term OEM contracts with rigid or infrequent price adjustment intervals prevent Company CI from passing through input cost increases in real time. Input costs rise immediately upon procurement and production, while selling prices remain locked under existing agreement terms until predetermined adjustment dates. This creates a temporary lag between cost escalation and price realization, dampening percentage margins during high-demand, cost-inflationary phases.

---

### 3. Moat and Pricing Power Assessment

* **Overwhelming Market Leadership (Exhibit 1):**
  The margin pressure is not driven by market share loss, customer attrition, or competitive price erosion. As of 2021, Company CI holds dominant, #1 market share across all four core product segments:
  * **Residential HVAC:** **~70% market share** (commanding lead over LG at ~13%, Rechi at ~2%, and others at ~15%).
  * **Product F:** **~35% market share** (leading position ahead of Company EN at ~5%, Company EU at ~7%, Company FA at ~6%, and Company J at ~9%).
  * **Refrigeration:** **~40% market share** (clear lead over competitors at ~10% each).
  * **Transport:** **~40% market share** (dominant share ahead of Company Z at ~20% and Company J at ~10%).

* **Customer Stickiness and Pricing Leverage:**
  Because Company CI controls ~70% of the Residential HVAC supply and 35-40% across commercial, transport, and refrigeration segments, OEMs rely heavily on Company CI's manufacturing scale, product quality, and supply continuity. Switching costs are significant, giving Company CI substantial leverage to pass through accumulated cost increases during scheduled contract price resets.

---

### 4. Sponsor / Carve-Out Strategic Diagnosis (2021-12 Anchor)

* **Underwriting Margin Recovery:**
  From the perspective of a private equity sponsor (Company ED) evaluating the carve-out in December 2021, recent margin compression should be treated as **cyclical and contractual**, not permanent or structural. As OEM contracts reach their renegotiation windows, price increases will catch up with costs, driving gross and EBITDA margins back toward historical benchmarks (~26-27% EBITDA margin).

* **Post-Carveout Value Creation Opportunities:**
  A standalone Company CI under private equity ownership can implement operational commercial excellence programs:
  1. Restructuring OEM contract terms to incorporate shorter adjustment intervals or dynamic indexation (pass-through mechanisms for raw materials and energy).
  2. Improving procurement efficiencies and manufacturing productivity.
  3. Capturing value from standalone focus following the retirement of Company BR's CEO and the execution of the carve-out.
