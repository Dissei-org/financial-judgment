# Why Company CI's Recent Margin Pressure Mattered for the Investment Case (as of 2022-06)

At the June 2022 anchor date, private equity sponsor **Company ED** was evaluating the carve-out of **Company CI** from its corporate parent **Company BR**. In this evaluation, understanding Company CI's recent margin compression was critical to underwriting the investment case, assessing baseline earnings power, and structuring value creation.

Based strictly on materials available at the **2022-06 anchor**, the significance of the recent margin pressure centers on the following key dimensions:

---

### 1. Historical Margin Profile vs. Recent Contraction (Exhibit 2)
Company CI's historical financials demonstrate robust, highly cash-generative performance over a 15-year period (2007–2021), but with noticeable margin erosion over the final two years:
* **Gross Margin:** Averaged ~35%–37% from 2013 to 2018 (peaking at **37.1% in 2017**), before softening to **33.9% in 2019**, recovering slightly to **34.9% in 2020**, and dropping to **33.2% in 2021**—its lowest level in a decade.
* **Adjusted EBITDA Margin:** Peaked at **27.3% in 2017** and **26.0% in 2018**, hovering at **24.8% in 2019** and **25.3% in 2020**, before falling to **24.4% in 2021** (down nearly 300 basis points from peak).
* **The Divergence Between Revenue and Profitability:** In 2021, Company CI experienced substantial top-line acceleration, growing **+18.7%** from $3,758 million in 2020 to **$4,460 million in 2021**. However, gross margin fell by 170 bps (from 34.9% to 33.2%) and Adjusted EBITDA margin contracted by 90 bps (from 25.3% to 24.4%). Despite generating record revenue, profitability did not keep pace.

---

### 2. Root Cause: Contractual Reset Lag, Not Structural Deterioration
The central question for Company ED was whether this compression reflected competitive impairment or a temporary timing mismatch. The case materials clarify the exact mechanism:
* **Long-Term OEM Contracts with Infrequent Price Adjustment Terms:** As noted in the case evidence (*Exhibit 2 case quote*), Company CI's recent margin contraction was *"primarily due to longterm contracts with original equipment manufacturers (OEMs) that included infrequent price adjustment terms."*
* **Cost Inflation vs. Price Realization Lag:** During 2020–2021, broader economic input costs and supply chain expenses increased (macro backdrop of rising inflation). However, because Company CI sold under multi-year or fixed-term agreements with OEMs where pricing adjustments occurred only periodically, Company CI absorbed higher raw material and manufacturing costs upfront before contractual adjustment windows opened.

---

### 3. Investment Significance for Company ED's Carve-Out Thesis

#### A. Transitory Margin Compression vs. Sustainable Competitive Moat
Crucially, the margin pressure did **not** signal loss of market share or eroding customer relevance. Exhibit 1 shows that Company CI maintained dominant global/market leadership across core product lines:
* **Residential HVAC:** Dominant **70% market share** (far exceeding nearest competitor LG at 13%).
* **Commercial / Product F:** Leading **35% share** (ahead of peers at 5%–9%).
* **Refrigeration:** Leading **40% share**.
* **Transport:** Leading **40% share**.
Because Company CI occupies an indispensable position in OEM supply chains with captive customer relationships, OEM customers cannot readily switch suppliers. Consequently, Company CI retained full underlying pricing power.

#### B. Springboard for EBITDA and Margin Expansion (Underwriting Upside)
Because the compression was contractual and temporary, it provided Company ED with a high-conviction base-case thesis (*Exhibit 3 projections*):
* **Contractual Catch-Up:** As long-term OEM contracts reached their scheduled reset periods, Company CI could pass through accumulated cost inflation, restoring gross margins toward historical norms (35%–37%).
* **Substantial Operating Leverage on an Expanded Base:** With revenues having scaled to $4.46 billion, a margin recovery of 150–250 basis points translates directly to **$65 million to $110+ million in incremental annual EBITDA**, offering powerful organic earnings growth.

#### C. Valuation Multiple and Entry Pricing Advantage
In private equity carve-outs, headline valuation multiples are often anchored on trailing-twelve-month (LTM) Adjusted EBITDA ($1,090M in 2021, depressed at 24.4% margin). An investor who recognizes that trailing EBITDA reflects an artificially compressed margin trough can underwrite the asset at an attractive entry valuation relative to its normalized mid-cycle cash flow generation.

#### D. Carve-Out Value Creation & Commercial Terms Optimization
Under parent company Company BR, commercial contracting was treated passively, tolerating inflexible adjustment terms. As an independent, PE-backed carve-out, Company ED identified immediate operational and governance levers:
* Upgrading commercial contracting discipline.
* Shifting OEM contracts from infrequent, static price resets to dynamic indexing, raw material pass-through formulas, or shorter reset cadences to shield the business from future inflation volatility.

#### E. Macro and Debt Financing Context (2022-06 Anchor)
By June 2022, macroeconomic headwinds were mounting:
* The Federal Reserve had commenced aggressive monetary tightening, delivering a **75 bps rate hike in June 2022** (with another signaled for July), pushing up borrowing costs.
* Leveraged loan market liquidity was tightening noticeably (Exhibit 9 shows institutional non-bank loan origination slowing sharply in 2Q22 to $56 billion, compared to $184 billion in 1Q21).
In a higher-interest-rate, tighter-financing environment, Company ED and its lenders needed assurance that Company CI possessed resilient, non-discretionary cash flows. Knowing that margin pressure was poised to reverse via contractual resets provided the requisite downside protection and debt-service coverage to support leverage in a turbulent capital market.

---

### Summary
At the June 2022 anchor, Company CI's recent margin pressure mattered because it was **diagnostic rather than fatal**: it was caused by **contractual lag in OEM pricing adjustments** amid rising input costs, rather than competitive weakness. For Company ED, this identified a clear, actionable catalyst: **pricing catch-up and contract modernization**, unlocking substantial margin recovery, EBITDA growth, and downside protection for the carve-out investment case.
