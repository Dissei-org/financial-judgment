# Company CI: is the $14 billion entry price attractive?

**Recommendation as of September 2022: treat $14 billion as broadly fair, not a compelling bargain against publicly traded HVAC manufacturers.** The price is close to peers on trailing earnings and slightly above them on forward earnings, despite CI's weaker EBITDA growth. The case's pro forma (PF) presentation makes the price look attractive, but that is a conditional underwriting case—not evidence of an unconditional entry discount.

## 1. The direct public-HVAC comparison

Exhibit 8 explicitly measures CI at a **$14 billion purchase price**, with LTM and NTM multiples centered on fiscal year-end September 30, 2022. This is the appropriate matched-date comparison, rather than mixing historical earnings with a different valuation date.

| Enterprise-value multiple | CI, unadjusted | HVAC OEM average | CI discount / (premium) | CI, PF | PF discount |
|---|---:|---:|---:|---:|---:|
| LTM EBITDA | 12.4x | 12.9x | 3.9% | 10.4x | 19.4% |
| NTM EBITDA | 13.4x | 13.2x | (1.5%) | 11.3x | 14.4% |
| LTM EBIT | 14.7x | 16.2x | 9.3% | 11.9x | 26.5% |
| NTM EBIT | 15.8x | 15.2x | (3.9%) | 13.0x | 14.5% |

*Source: Exhibit 8, “Public Comparable Companies.” Discounts calculated as 1 − CI multiple / HVAC average; “unadjusted” denotes the figures before the exhibit's PF presentation.*

The modest trailing EBITDA discount disappears on forward earnings; EBIT gives the same directional result. Applying the current HVAC EBITDA multiples to CI's earnings implicit in Exhibit 8 yields approximately **$14.6 billion on LTM earnings** ($14bn × 12.9/12.4), but only **$13.8 billion on NTM earnings** ($14bn × 13.2/13.4). These are indicative calculations from rounded multiples, not precise appraisals. They nevertheless show that $14 billion is around the public-market benchmark, rather than materially below it.

Historical peer valuations do not establish a large bargain either. CI's 13.4x NTM EBITDA compares with HVAC averages of **14.4x over five years** and **13.5x over ten years**: discounts of approximately 7% and less than 1%, respectively. Its 15.8x NTM EBIT is below the five-year average of 16.8x but above the ten-year average of 15.6x. Thus the price is not deeply discounted to long-run HVAC valuations. [Exhibit 8]

## 2. CI's growth does not justify a premium

CI's five-year historical revenue growth was **5.2%**, versus **2.1%** for HVAC OEMs. However, the more valuation-relevant earnings measures are weaker: historical EBITDA growth was **1.9% versus 8.4%**, and two-year forward EBITDA growth was **3.3% versus 7.2%**. [Exhibit 8]

The operating history reinforces this concern: adjusted EBITDA margin declined from **27.3% in 2017 to an estimated 23.2% in 2022**, despite revenue increasing from $3.925 billion to $5.060 billion. [Exhibit 2] My inference is that revenue growth alone does not support a peer-level or premium earnings multiple; the weaker conversion into EBITDA makes the small trailing discount less persuasive.

Nor would I substitute the higher-valued “comparable margin industrials” group to manufacture upside. Its current NTM EBITDA multiple is 15.3x, but its forward EBITDA growth is also much higher at **15.7%**, versus CI's 3.3%. The HVAC OEM group directly addresses the question. [Exhibit 8]

## 3. The PF discount is real in the exhibit—but conditional

The strongest argument for attractiveness is CI's **11.3x PF NTM EBITDA and 13.0x PF NTM EBIT**, both approximately 14% below HVAC peers. ED should take that potential seriously. The case records completed operational diligence, an identified cost-savings target, validation of standalone-cost assumptions, and transition-service arrangements. [Exhibit 4]

Nevertheless, Exhibit 8 does not reconcile its PF multiples to the unadjusted figures. The EBITDA bridge separately forecasts growth from **$1.130 billion in 2022 to $1.614 billion in 2027**, including $148 million of cost savings, $105 million of strategic pricing and $72 million of SG&A leverage, alongside regional growth and negative offsets. Those are forecasts available at the deal table, not achieved results—and the bridge should not be assumed to explain every PF adjustment. [Exhibit 5]

Earnings definitions also matter: Exhibit 3 forecasts 2023 EBITDA of **$1.046 billion**, consistent with approximately 13.4x at $14 billion, and notes $41 million of standalone costs and quality-of-earnings adjustments absent from Exhibit 2's historical figures. Simply dividing by Exhibit 2's higher 2022 EBITDA would therefore overstate cheapness on the relevant forward basis. [Exhibits 2–3]

**Bottom line:** I would not recommend $14 billion on the assertion that CI is cheap versus public HVAC manufacturers. It is approximately a peer-priced entry for a slower-growing earnings stream. ED can justify attractiveness only by validating the PF adjustments and the operational improvement case; absent that validation, the public-comparables evidence supports fair value, not a meaningful margin of safety.
