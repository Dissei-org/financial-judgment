# Counterfactual capital structure — as of September 2022

**Company ED would have needed approximately $4 billion of replacement financing to pay the same price. The more credible restructuring would have been a substantially larger ED/co-investor equity commitment, potentially supplemented by negotiated preferred or private credit—not simply replacing all seller participation with additional senior debt.** BR would exchange its continuing investment exposure for cash at closing; ED, replacement investors and, depending on the funding mix, external lenders would assume that exposure.

## 1. Size of the hole

The proposed structure included **$2.25 billion of BR seller debt at 5% PIK**, senior to preferred equity, and **approximately $1.70 billion of BR common equity for 40% common ownership**. ED and its co-investors supplied $2 billion of convertible preferred and approximately $2.55 billion of common equity; third-party senior debt was $5.5 billion. [Table 1, *Proposed Deal Structure*]

The detailed sources-and-uses schedule refines the seller's 40% equity line to $1.721 billion and ED's common contribution to $2.581 billion. Thus, removing both seller instruments creates a **$3.971 billion gap** ($2.250 billion + $1.721 billion), versus $3.95 billion using the rounded term sheet. Total uses remain **$14.052 billion**: $14 billion purchase price + $362 million expenses − $310 million sign-to-close cash generation. [Exhibit 10]

This is replacement funding, not an increase in the acquisition price. The calculation holds the other closing assumptions constant; new financing fees or discounts could increase the actual requirement.

## 2. How ED could reshape the stack

Illustrative structures, in $ billions, using Exhibit 10's amounts:

| Source | Proposed | All-equity replacement | All-external-debt replacement |
|---|---:|---:|---:|
| Third-party debt | 5.500 | 5.500 | 9.471 |
| BR seller note | 2.250 | — | — |
| ED/replacement-investor preferred and common | 4.581 | 8.552 | 4.581 |
| BR common rollover | 1.721 | — | — |
| **Total** | **14.052** | **14.052** | **14.052** |

**Equity-heavy route.** ED would raise another $3.971 billion from its fund and/or a larger co-investment consortium. If the existing $2 billion preferred remained unchanged and the entire replacement were common, buyer-side common would become $6.552 billion. ED and its co-investors would collectively own the common equity formerly shared with BR; ED alone would not necessarily own 100%. This preserves cash-flow flexibility and removes the seller debt, but requires considerably more buyer capital at risk. Returns would need re-underwriting: lower leverage generally reduces equity-return amplification, while acquiring BR's former equity also gives buyers additional upside.

**Hybrid route.** ED could combine more common equity with additional preferred equity or subordinated/private debt, if investors would commit. PIK instruments could preserve near-term liquidity, but accumulate claims against future proceeds. New investors could require stronger economics, governance or priority rights. The existing preferred already carried 7% PIK, conversion at a 10% premium to the deal price, and priority sell-down after conversion following an IPO. Enlarging or redesigning that layer would require negotiation, not an assumption that identical terms were available. [Table 1]

**Debt-heavy route.** Replacing everything with outside debt raises external borrowing by about 72%, to $9.471 billion. Total debt also rises from $7.750 billion to $9.471 billion because the former seller equity becomes debt. This was particularly challenging given the case's stated severe scarcity of high-yield capital and declining leveraged-loan issuance. [Exhibit 9 and its accompanying case quotation]

Existing senior facilities were already priced at SOFR + 4.50% and SOFR + 6.75%, with original-issue discounts, amortization and, for the Term Loan A, a first-lien net-leverage covenant and later spread step-ups. At the disclosed September SOFR of 2.42%, those coupons were approximately 6.92% and 9.17%, versus the seller note's 5% PIK. Even at those existing—not assured marginal—rates, $3.971 billion of additional cash-pay debt implies roughly **$275–364 million of annual interest**, before fees and amortization. The seller equity had no contractual cash-interest obligation and the seller note could capitalize interest. ED therefore could not presume either sufficient debt capacity or acceptable liquidity merely because the sources-and-uses arithmetic balanced. [Table 1]

## 3. How risk-sharing changes

- **BR:** loses its 40% common upside and downside, and its seller-note repayment exposure. It no longer shares acquisition investment risk through those instruments, although contractual carve-out obligations would not automatically disappear.
- **ED and new equity investors:** absorb the operating, valuation and exit exposure previously shared with BR. More common equity lowers company-level financial risk but places more dollars of loss-bearing capital with buyers. Additional preferred shifts priority away from common rather than eliminating economic risk.
- **External lenders and Company CI:** if debt supplies the replacement, lenders assume more credit exposure and CI faces greater debt-service, refinancing and potentially covenant pressure. Existing lenders also lose BR's junior capital cushion unless equivalent loss-absorbing capital replaces it.
- **Execution incentives:** BR's retained equity aligned it economically with successful separation and subsequent value creation. Without that stake, ED would need to rely more heavily on enforceable transition arrangements and its own execution capabilities. Diligence had established TSAs and a standalone-functions roadmap, but these do not substitute for shared investment exposure. [Exhibit 4]

**Bottom line:** maintaining the price required ED to secure roughly $4 billion more committed capital and accept either a larger buyer equity exposure, more expensive/riskier leverage, or both. It would also lose BR's continuing financial alignment. If acceptable replacement commitments were unavailable, closing at the same price was not assured.
