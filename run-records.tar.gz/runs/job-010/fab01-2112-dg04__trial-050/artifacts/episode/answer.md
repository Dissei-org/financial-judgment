# Company CI margin diagnosis — as of December 2021

**The best-supported diagnosis is primarily a contractual price-cost lag, not demonstrated structural deterioration of the business.** Long-term OEM agreements limit how frequently Company CI can adjust selling prices. That creates exposure when costs move before contractual prices can reset. The case explicitly attributes the recent margin decline primarily to these infrequent price-adjustment terms. This is a potentially recoverable squeeze, but recovery is not established at the anchor. [Exhibit 2, accompanying case quotation, p. 11]

## What the financials show

| Metric | 2019A | 2020A | 2021A |
|---|---:|---:|---:|
| Revenue ($m) | 4,068 | 3,758 | 4,460 |
| Gross margin | 33.9% | 34.9% | 33.2% |
| Adjusted EBITDA ($m) | 1,010 | 950 | 1,090 |
| Adjusted EBITDA margin | 24.8% | 25.3% | 24.4% |

In 2021, revenue rebounded **18.7%** and adjusted EBITDA increased **14.7%**, yet gross margin contracted approximately **170 basis points** and EBITDA margin approximately **90 basis points**. Thus, the immediate issue is weaker profit conversion despite recovering sales—not falling absolute EBITDA. The larger compression at gross-profit level is consistent with a price-cost mismatch rather than an explanation centered solely on overhead. These figures do not, however, isolate cost, price, volume, or mix effects. Also, the recent decline was not uninterrupted: both margins improved in 2020 before falling in 2021. [Exhibit 2]

## Interpretation and limits

The evidence does **not** justify concluding that Company CI has lost its competitive franchise. Its 2021 positions remain substantial: approximately 70% in Residential HVAC, 35% in Product F, and 40% each in Refrigeration and Transport. These shares support a strong incumbent position, but a single-year snapshot cannot prove stable share or unrestricted pricing power; the OEM contracts themselves constrain near-term pricing flexibility. [Exhibit 1]

Equally, “contractual lag” should not be treated as a guaranteed, harmless one-off. The mechanism can recur, and the available evidence does not establish reset dates, recoverable amounts, or whether customers will accept full cost recovery. Nor does the primary explanation rule out secondary operating or mix effects.

**Underwriting implication:** distinguish current earnings from potentially normalized earnings, but do not automatically restore historical peak margins. Validate OEM reset schedules, indexation/pass-through provisions, customer-level price-versus-cost movements, and the residual volume/mix/productivity bridge. At the anchor, the appropriate conclusion is **primarily repricing friction with potential for recovery—not proven permanent margin impairment, and not proven future recovery**.
