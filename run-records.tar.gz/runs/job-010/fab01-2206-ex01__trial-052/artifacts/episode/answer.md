# Why Company CI’s recent margin pressure mattered — as of June 2022

**The pressure made sustainable earnings—not simply revenue growth—a central underwriting question.** For Company ED, the investment distinction was whether CI’s lower margins reflected a recoverable contractual pricing lag or a lasting reduction in profitability. The former could offer value-creation upside; the latter would undermine valuation and debt capacity.

### The revenue rebound was not fully translating into profitability

The latest available annual financials showed 2021 revenue of **$4.460 billion**, up **18.7%**, while adjusted EBITDA increased only **14.7%**, to **$1.090 billion**. EBITDA margin fell from **25.3% in 2020 to 24.4% in 2021**, and gross margin declined from **34.9% to 33.2%**. EBITDA margin was also below **26.0% in 2018** and **27.3% in 2017**. Thus, absolute EBITDA had recovered, but CI was earning less profit per sales dollar. The decline was not uninterrupted—margins improved in 2020—but the latest rebound had not restored earlier profitability. **[Exhibit 2, Company CI historical financials]**

### The cause supported a recovery thesis, but also exposed a weakness

The case explicitly attributes the recent margin decline primarily to **long-term OEM contracts with infrequent price-adjustment terms**. **[Exhibit 2, accompanying case quotation, p. 11]** Such terms can delay passing higher costs through to customers: established customer relationships do not necessarily provide immediate pricing flexibility.

That explanation mattered because it pointed toward a potentially addressable pricing-timing problem rather than establishing a collapse in demand or competitive position. CI’s substantial reported shares across its businesses—including 70% in residential HVAC—provided context for a resilient-franchise argument. **[Exhibit 1]** Nevertheless, market position alone did not override contractual restrictions, and “primarily” contractual pressure did not prove that every lost margin point would return.

### Implications for the investment case

- **Valuation and upside:** Buying on depressed earnings could be attractive if repricing subsequently restored margins. Conversely, paying for fully normalized EBITDA before validating that recovery could mean overpaying. At 2021 revenue, one percentage point of EBITDA margin represented approximately **$44.6 million of annual EBITDA**, holding revenue constant—a meaningful sensitivity, not a forecast.
- **Execution and diligence:** The investment thesis needed evidence on contract reset dates, pass-through provisions, customer acceptance, and whether price increases could catch up with costs without losing volume. Recovery should be underwritten with timing and downside scenarios, not treated as automatic.
- **Leverage and resilience:** Persistently lower EBITDA would, all else equal, reduce cash available for debt service and deleveraging and increase debt/EBITDA at a given debt amount. That mattered in a financing environment where the case already highlighted scarce high-yield debt capital and the need for a risk-mitigating structure. **[Exhibit 9, accompanying case quotation, p. 19]**

**Bottom line:** At the anchor, margin pressure was both a potential source of investment upside and a warning against aggressive underwriting. The case depended on establishing achievable, sustainable margins and financing the business to withstand delayed recovery—not assuming that historical peak margins would return.
