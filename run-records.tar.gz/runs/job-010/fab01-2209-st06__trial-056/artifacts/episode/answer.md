# Recommendation at the September 2022 signing decision

**Company ED should make carve-out / standalone-readiness diligence the controlling gate before signing**, with finance/QoE and operations feeding into one integrated conclusion: **can CI operate independently of Company BR, at a verified cost and with sufficient cash generation to support the proposed capital structure?** This is a requirement for a fully costed, executable separation plan—not for every separation activity to be completed before signing.

## Why this workstream should control the decision

**1. ED is buying standalone earnings, not simply the historical performance of a division.** Exhibit 4 identifies the critical carve-out questions directly: bottoms-up validation of management's standalone-cost assumptions, the specific personnel transferring, transition service agreements (TSAs), and a roadmap to stand up the new organization. Finance, tax, HR, operations, and IT diligence can each look satisfactory while the combined separation plan still leaves an essential service or cost unaccounted for. The carve-out workstream must integrate those conclusions.

This distinction already matters in the financial evidence. Exhibit 2 shows 2022E adjusted EBITDA of **$1,175 million**. Exhibit 3 explicitly says its forecasts include **$41 million of incremental standalone costs and QoE adjustments not reflected in those historical financials**. Exhibit 5 starts its growth bridge at **$1,130 million**, another basis that should be reconciled rather than assumed equivalent. The $41 million is a combined adjustment, not proof that the entire separation has been costed or funded.

**2. The investment case depends materially on execution after separation.** The 2022–2027E bridge increases EBITDA from $1,130 million to $1,614 million. Strategic pricing ($105 million), SG&A leverage ($72 million), and cost-saving initiatives ($148 million) together contribute **$325 million—about 67% of the net $484 million increase**. These are forecast contributions, not realized results. ED must establish whether the new company has the people, systems, authority, and resources to deliver them without double-counting savings against replacement corporate functions. The bridge's $6 million standalone-cost decrement is not a substitute for the full standalone-cost analysis. [Exhibit 5]

**3. Separation errors would hit cash precisely when financing is expensive.** Exhibit 3 forecasts 2023E EBITDA of $1,046 million, $370 million of capex, and a $102 million deduction combining minority interest, stand-up costs, and one-time expenses. That last amount should not all be characterized as separation spending, but it is a material cash demand alongside elevated capex.

The proposed structure includes **$5.5 billion of floating-rate senior debt** and a **$2.25 billion seller note**. At the exhibit's September 30 SOFR assumption of 2.42%, the senior loans imply approximately **$439 million of annual cash interest before amortization**, assuming full balances and no hedging; a further 100-basis-point increase would add approximately $55 million annually. The seller note's 5% PIK avoids immediate cash interest but increases its claim. Thus understated standalone costs or delayed savings would reduce both equity value and liquidity. [Proposed Deal Structure, table_1]

The financing backdrop reinforces this concern: institutional leveraged-loan volume fell sharply between 1Q22 and 3Q22. ED should not assume that an unbudgeted separation problem can readily be refinanced. This is a September risk assessment, not a prediction of subsequent events. [Exhibit 9]

## What must be demonstrated before signing

The evidence is encouraging, not an established failure: Exhibit 4 reports detailed bottoms-up carve-out work, identified transferring personnel, TSAs “well in-place,” and a stand-up roadmap. It also reports completed diligence across the other listed functions. **The gate is verification of these deliverables, not a claim that diligence has not occurred.** ED should require:

- **An agreed operating perimeter and accountable people:** critical functions, assets, systems, contracts, and responsibilities mapped to CI or a contracted provider; essential employee transfers and retention arrangements sufficiently secured to make Day 1 credible.
- **Contractually secured transition support:** TSA scope, service standards, pricing, duration, extension rights, and remedies, with an owned, funded exit plan. BR's proposed 40% common-equity retention does not itself guarantee service continuity. [table_1]
- **A reconciled standalone financial model:** recurring replacement costs, temporary TSA charges, one-time stand-up spending, capex, working capital, and savings implementation costs separately identified, with no omissions or double counting. Reconcile historical, bridge, forecast, and lender EBITDA definitions.
- **A combined downside case:** delayed TSA exits, higher standalone costs, weaker demand/pricing, slower savings, and higher interest rates tested together against liquidity and the proposed leverage covenant. Unproven savings should not be essential to remaining solvent or covenant-compliant.

## Go/no-go rule

**Sign only if the separation is executable and the downside standalone cash flows support the financing with credible headroom.** If critical dependencies remain unsecured or costs remain unbounded, delay signing, reprice/restructure, or obtain enforceable seller support; if the resulting economics fail, do not proceed.

Commercial attractiveness and financing certainty remain necessary checks. CI's strong reported market positions do not establish separability, and committed financing cannot cure an unworkable operating perimeter. [Exhibit 1] The carve-out workstream should therefore control the go/no-go decision because it establishes whether the business ED is underwriting can actually exist—and earn and retain cash—outside BR.
