# Company CI: resilience to weaker demand

**As of December 2021, I would expect Company CI to be relatively resilient at the operating-earnings level—but not recession-proof.** The strongest evidence is its actual performance through earlier demand shocks, supported by leading market positions. That does not establish that a leveraged carve-out would be equally resilient financially.

## Why the business looks relatively resilient

**1. Profits held up better than sales in important historical downturns.** Company documents show the following (Exhibit 2; dollar amounts in millions):

| Period | Revenue change | Adjusted EBITDA change | Adjusted EBITDA margin |
|---|---:|---:|---:|
| 2009 | −15.3% | −12.2% | 21.5% → 22.3% |
| 2012 | −5.6% | −4.4% | 25.3% → 25.6% |
| 2020 | −7.6% | −5.9% | 24.8% → 25.3% |

In 2009, revenue fell from $3,449 million to $2,921 million, yet CI still generated $650 million of adjusted EBITDA. In 2020, it generated $950 million despite the sales contraction. Gross margins also increased in both years. This is evidence of earnings durability rather than the severe negative operating leverage one might fear from an industrial business. The figures do not, however, identify how much protection came from costs, mix, or pricing.

Historical recovery was also encouraging: 2010 revenue and EBITDA exceeded their 2008 levels, and 2021 revenue of $4,460 million and EBITDA of $1,090 million exceeded 2019 levels. Across 2007–2021, adjusted EBITDA margins remained above 20%. These observations support resilience; they do not guarantee the speed of any future recovery. [Exhibit 2]

**2. CI entered a potential slowdown with strong competitive positions.** The 2021 share exhibit indicates approximately 70% in residential HVAC, 35% in Product F, and 40% each in refrigeration and transport. CI is the largest individually identified participant in each displayed category. Such positions plausibly help defend customer relationships and share when markets weaken. Exposure to several categories also offers some potential diversification, although market shares are not revenue weights and these markets could weaken together. The chart-derived percentages are approximate. [Exhibit 1]

## Why the conclusion needs qualifications

- **Sales and earnings are still cyclical.** A 15.3% revenue decline is material. Moreover, in 2019 EBITDA fell 7.0% on only a 2.7% revenue decline, with its margin falling from 26.0% to 24.8%. Earnings have not always outperformed sales. [Exhibit 2]
- **Strong market share does not mean immediate pricing flexibility.** Exhibit 2's accompanying case note attributes margin pressure primarily to long-term OEM contracts with infrequent price adjustments. Such contracts can constrain cost pass-through; they should not be treated as guaranteed purchase volumes. In 2021, EBITDA grew 14.7% versus revenue growth of 18.7%, and the EBITDA margin fell from 25.3% to 24.4%. Weaker demand combined with persistent cost pressure would be a tougher scenario than weaker demand alone. [Exhibit 2 and accompanying case quotation]
- **Operating resilience is not the same as financing resilience.** These exhibits do not establish replacement/recurring revenue shares, cash conversion, standalone carve-out costs, or debt-service headroom. I would not infer those protections from EBITDA or market share alone.

**Bottom line:** Expect CI to remain meaningfully profitable through a demand slowdown, with some historical basis for EBITDA declining less than sales. Do not underwrite flat earnings, automatic margin recovery, or a debt structure that requires uninterrupted growth.
