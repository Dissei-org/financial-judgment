## Relative market position as of June 2022

**The segment-share exhibit indicates that Company CI is the leading player across all four depicted segments, with exceptional dominance in Residential HVAC and substantial—but not majority—positions elsewhere.** This inference uses the exhibit's 2021 snapshot, not evidence of subsequent developments.

| Segment | Approximate CI share | Evidence of relative position |
|---|---:|---|
| Residential HVAC | 70% | LG has about 13% and Rechi 2%. CI is over five times the largest named rival and exceeds all competitors combined. |
| Product F | 35% | The largest individually named rival, Company J, has about 9%; other named rivals have roughly 5–7% each. CI leads a fragmented field despite holding less than half the market. |
| Refrigeration | 40% | Companies EN, EV and BE each have about 10%, making CI roughly four times any of these named competitors. |
| Transport | 40% | Company Z has about 20% and Company J 10%; CI is roughly twice the next-largest named competitor. |

**Business implication:** CI appears to be a broadly established market leader rather than a small challenger. Its strongest relative position is Residential HVAC. In the other three segments, its large individual lead suggests potential scale advantages, but competitors collectively still hold 60–65% of the market; leadership should not be confused with overwhelming control.

**Evidence and limits:** Exhibit 1, *“Company CI (as of 2021),”* sourced to company documents. Shares are calculated from the widths of the stacked ranges, not their cumulative endpoints; the exhibit metadata identifies those boundaries as approximate chart readings. “Other” and “Other Captive” are grouped categories, not individual rivals. Without segment market sizes, these percentages cannot establish a weighted overall market share. The exhibit alone also does not prove pricing power, profitability, a durable moat, or that the 2021 positions persisted unchanged through June 2022.
