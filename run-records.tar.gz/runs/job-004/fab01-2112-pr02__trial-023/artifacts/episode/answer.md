Yes, Company CI would be expected to be relatively resilient if demand conditions weakened after the anchor.

Based on the provided case materials, the company has two major factors supporting its resilience:

1. **Proven Margin Expansion During Historical Downturns:** As shown in Exhibit 2, Company CI has a track record of expanding its profitability margins even when facing severe demand shocks and revenue contractions. 
   - During the 2009 Great Recession, revenue declined by 15.3%, yet the company's gross profit margin expanded from 28.4% to 29.7% and its Adjusted EBITDA margin expanded from 21.5% to 22.3%.
   - During the 2020 pandemic downturn, revenue declined by 7.6%, but gross profit margin again expanded from 33.9% to 34.9%, and Adjusted EBITDA margin increased from 24.8% to 25.3%.

2. **Dominant Market Leadership:** As shown in Exhibit 1, Company CI holds very strong, often dominant market share positions across its key segments. It commands 70% of the Residential HVAC market, 40% of Refrigeration, 40% of Transport, and 35% of Product F. This level of market entrenchment likely affords the company strong pricing power and structural advantages that help protect its margins when overall market demand weakens.

Therefore, considering its historical ability to protect and even grow margins during recessions, supported by its dominant market share, Company CI is well-positioned to weather weakened demand conditions.
