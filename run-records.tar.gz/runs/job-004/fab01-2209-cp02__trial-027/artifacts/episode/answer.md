## Conclusion

Yes, the $14 billion entry valuation for Company CI is highly attractive when measured against how public equity markets value comparable HVAC manufacturers. The valuation presents a meaningful discount to both current and historical peer multiples, especially when accounting for pro forma operational improvements.

## Reasoning and Evidence

1. **Favorable Current Multiples (Discount to Peers):**
Based on Exhibit 8, assuming the $14 billion purchase price, Company CI's Pro Forma (PF) LTM EBITDA multiple is 10.4x and its PF NTM EBITDA multiple is 11.3x. Both of these multiples represent a clear discount compared to the current averages for comparable HVAC OEMs, which trade at 12.9x LTM and 13.2x NTM. Even on a reported (non-adjusted) basis, Company CI's 12.4x LTM multiple is slightly cheaper than the HVAC OEM average.

2. **Discount to Historical Averages:**
Public equity markets have consistently valued comparable HVAC manufacturers at higher multiples over the long term. The HVAC OEMs have a 5-year average NTM multiple of 14.4x and a 10-year average NTM multiple of 13.5x. Company CI's entry multiple of 11.3x (PF) or 13.4x (Reported) offers an attractive entry point that sits below these historical benchmarks.

3. **Substantial Discount to Margin Comparables:**
The case evidence also highlights a set of "Comparable Margin Industrials" to benchmark companies with similar profitability profiles. These industrials currently trade at an average LTM EBITDA multiple of 19.0x and an NTM of 15.3x. Against these peers, Company CI's multiples (10.4x PF LTM / 11.3x PF NTM) signify an even deeper value dislocation.

4. **Support for Pro Forma Adjustments:**
The attractiveness of the multiples heavily relies on the "PF" (Pro Forma) adjustments (improving the LTM multiple from 12.4x to 10.4x). The case evidence confirms these adjustments are credible. Exhibit 4 outlines that detailed operations and carve-out diligence have been completed, with advisors successfully identifying "total cost-savings targets" and validating "management standalone cost assumptions." This clear path to synergy and cost realization ensures that the pro forma valuation discount is grounded in actionable operational plans.

In summary, grounded in the public comparable data from Exhibit 8, acquiring Company CI at a $14 billion enterprise value is an attractive proposition because it secures the asset at a tangible discount to current HVAC OEM multiples, historical industry averages, and comparably profitable industrial peers.
