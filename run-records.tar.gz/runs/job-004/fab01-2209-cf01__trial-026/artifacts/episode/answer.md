Based on the case materials available through September 2022, if Company BR had declined to roll equity and provide a seller note, the deal's financing and risk profile would have shifted dramatically.

### Reshaping the Capital Structure

Company BR’s proposed contribution consists of **~$3.97 billion** in total value:
*   **$2.25 billion Seller Note** (5% PIK, subordinated to preferred equity)
*   **$1.721 billion in Common Equity** (representing a 40% stake)

Without these contributions, Company ED would have had to replace ~$3.97 billion to meet the total $14.05 billion purchase price and fees. 

**Constraints on New Debt:** Raising an additional ~$4 billion in third-party debt would have been unviable. As of Q3 2022, the macroeconomic environment was rapidly tightening to tame inflation, with the Federal Reserve enacting supersized rate hikes (75 bps increases). Consequently, the U.S. leveraged loan market essentially froze. Non-bank institutional leveraged loan volume plummeted from $112 billion in Q1 2022 to just $22 billion in Q3 2022. The deal already contemplated $5.5 billion in third-party debt; pushing this to ~$9.5 billion in a collapsed debt market was not feasible.

**The Equity Gap:** Therefore, Company ED would have been forced to fill the $3.97 billion gap almost entirely with additional equity. Fortunately, Company ED had the capacity, having closed its record $26.2 billion Product X fund in 2019. ED’s total equity commitment would have surged from ~$4.58 billion (preferred + common) to **~$8.55 billion**, representing over 60% of the entire capitalization. 

### Shift in Risk-Sharing

**1. Complete Transfer of Post-Close Risk to Company ED:** 
In the proposed structure, Company BR acts as a major financing partner, absorbing substantial downside risk through its subordinated seller note and 40% equity roll, while also sharing in the upside. If BR had declined, they would have achieved a "clean exit"—taking all cash upfront and entirely offloading operational and macroeconomic risks (such as a potential inflation-induced recession). Company ED and its co-investors would assume 100% of the post-close downside and execution risk.

**2. Cash Flow and Return Implications:**
Company BR's Seller Note features a 5% PIK (Payment-in-Kind) interest rate, which preserves Company CI's near-term liquidity because it doesn't require cash interest payments. If ED had tried to replace even a fraction of this with third-party cash-pay debt, the interest burden would have severely strained CI's cash flow. By replacing it entirely with equity, ED protects the company's cash flow but massively dilutes its own return metrics; underwriting an $8.55 billion equity check would heavily depress the firm's projected Internal Rate of Return (IRR).
