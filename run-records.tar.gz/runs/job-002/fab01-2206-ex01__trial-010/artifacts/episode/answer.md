# Why Company CI's recent margin pressure mattered at the June 2022 anchor

## Bottom line
Company CI's margins had slipped from their 2017 peak and compressed further in 2021. That mattered because the buyer, Company ED, was a private equity sponsor. It would price a leveraged carve-out on EBITDA, just as costs were rising and debt was getting dearer and scarcer. The central question was whether the pressure was structural or temporary. The case says the decline was primarily due to long-term OEM contracts with infrequent price-adjustment terms. On that reading, the pressure was mainly a pricing lag. A dominant-share business can fix a pricing lag through contract repricing, which makes margin recovery a potential value-creation lever. But the diligence and leverage risk remained real, and the lag would stay a drag until contracts were reset.

## What the evidence showed (Exhibit 2, USD millions)
- Gross margin peaked at 37.1% in 2017. It then fell to 35.1% (2018), 33.9% (2019), 34.9% (2020) and 33.2% (2021).
- Adj. EBITDA margin peaked at 27.3% in 2017. It then fell to 26.0% (2018), 24.8% (2019), 25.3% (2020) and 24.4% (2021).
- In 2021, revenue rebounded 18.7% to $4,460M, but Adj. EBITDA grew only 14.7% to $1,090M. Gross profit rose only about 13%, to $1,483M. Volume came back, but profit did not keep pace, which is the signature of costs running ahead of contracted prices.
- At the 2017 EBITDA margin of 27.3%, 2021 revenue would have produced about $1,218M of EBITDA instead of $1,090M. That is a gap of roughly $125-130M, or about 12% of the EBITDA a buyer would lever and capitalise.
- Case explanation: margins declined over the past two years primarily because of long-term contracts with original equipment manufacturers (OEMs) that included infrequent price-adjustment terms.

## Why it mattered for the investment case
1. **Valuation and entry price.** A sponsor capitalises EBITDA at a multiple. Treating 24.4% as the run-rate margin, rather than 26-27%, moves enterprise value by the multiple times roughly $100M+. Buyer and seller would argue over normalised EBITDA. Company ED base-case projections were referenced (Exhibit 3) but are not visible in the dataroom.

2. **Structural versus temporary: the core diligence question.** If the compression came from lost competitiveness, it would undercut the thesis. The case attributes it instead to contract mechanics: fixed or slowly adjusting prices on long OEM agreements while input costs rose. The market-position data (Exhibit 1, as of 2021) supports the pricing-power reading. Company CI held about 70% of residential HVAC, 40% of refrigeration, 40% of transport and 35% of Product F. A business with that share and installed position should be able to renegotiate terms, add escalators or index prices to inputs as contracts roll.

3. **Upside lever for a carve-out owner.** Under a corporate parent, commercial terms may not have been optimised. A focused private equity owner could build a value-creation plan around contract repricing, pass-through clauses and cost actions. Margin recovery toward the historical 25-27% range was an identifiable lever on top of volume growth.

4. **Timing risk in an inflationary environment.** The same contracts that caused the lag also mean relief arrives only as contracts reset. With inflation rising into 2022, costs could keep outrunning prices in the near term. That would depress EBITDA in the first holding years, exactly when leverage is highest. Exhibit 6 tracks PCE inflation; its source is titled Inflation Is Still High and Widespread.

5. **Financing and leverage capacity.** A carve-out buyout depends on debt sized off EBITDA. At the anchor, the financing window was tightening:
   - Institutional leveraged loan volume fell from a record of about $184B in 1Q21 to $112B in 1Q22 and $56B in 2Q22 (Exhibit 9).
   - The Federal Reserve raised rates by 75bp in June 2022.
   Lower or less certain EBITDA meant less debt capacity and higher interest cost. Covenant headroom would also be thinner, so margin credibility directly affected deal feasibility and equity returns.

6. **Deal context.** Carve-out discussions had become more active after Company BR's CEO retired in 2021. Company ED had scale to act, having closed its Product X fund at a record $26.2B in 2019. The margin story therefore shaped how Company ED would underwrite, price and structure a bid. Key inputs were normalised EBITDA, the pace of contract resets and conservative leverage.

## Net assessment at the anchor
The margin pressure was a key underwriting issue, not necessarily a deal-breaker. The evidence pointed to a contract and pricing-lag cause in a business with dominant market shares. That supports a thesis in which the sponsor buys at depressed margins and recovers them through repricing. The investor still had to verify several things before relying on that thesis:
- the contract roll-off schedule and the price-adjustment mechanics;
- how far input-cost inflation could be passed through;
- whether OEM customers would accept new terms without share loss.

The investor also needed to size leverage cautiously given tightening credit and rising rates. Nothing after June 2022 is assumed here.

Sources: Exhibits 1, 2, 6 and 9; the 2021-12 and 2022-06 pre-anchor timelines; case text on Exhibit 2 (OEM contract explanation).
