# Company CI at $14bn: is the entry price attractive against public HVAC peers? (view as of Sept 2022)

## Bottom line
Yes, but only moderately, and only if the planned improvements are delivered.

- On reported EBITDA, $14bn is roughly in line with the public HVAC manufacturers (OEMs). It is not a bargain, especially since CI grows much more slowly than they do.
- On pro forma (PF) EBITDA, which includes improvements Company ED has diligenced, the price is a clear discount to peers today, to peers' own 5- and 10-year averages, and to industrials with similar margins.
- The deal therefore does not depend on the valuation multiple rising. The risk sits in execution: roughly $200m of EBITDA improvement must actually be delivered, in a weakening economy.
- My recommendation is to proceed at $14bn, but not to pay above it. Headroom only exists on the PF basis, and that part of the value is created by Company ED, not bought from the seller.

## 1. What the multiples say (Exhibit 8, assuming a $14bn price, fiscal year ending 9/30/22)

| EBITDA multiple | CI, reported | CI, pro forma | HVAC OEM avg | Similar-margin industrials |
|---|---|---|---|---|
| Current, last 12 months (LTM) | 12.4x | 10.4x | 12.9x | 19.0x |
| Current, next 12 months (NTM) | 13.4x | 11.3x | 13.2x | 15.3x |
| 5-year average, NTM | n/a | n/a | 14.4x | 16.4x |
| 10-year average, NTM | n/a | n/a | 13.5x | 14.7x |

EBIT multiples show the same pattern:
- CI is 14.7x LTM and 15.8x NTM on reported figures, and 11.9x and 13.0x pro forma.
- HVAC peers are 16.2x LTM and 15.2x NTM.
- Their 5-year and 10-year average NTM multiples are 16.8x and 15.6x.

Peer P/E ratios (17.6x NTM against a 20.3x 5-year average) show the sector is already trading below its own history.

**Reported basis.**
- 12.4x LTM is about a 4% discount to peers' 12.9x.
- 13.4x NTM is about a 2% premium to peers' 13.2x.
- The NTM multiple is higher because forward EBITDA falls. The implied EBITDA figures tie to the case exhibits:
  - $14bn / 12.4x = about $1.13bn, matching the $1,130m 2022 EBITDA in Exhibit 5.
  - $14bn / 13.4x = about $1.045bn, matching the $1,046m 2023E EBITDA in Exhibit 3.
- Conclusion: on reported numbers, the price is at the peer multiple, not below it.

**Pro forma basis.**
- 10.4x LTM and 11.3x NTM are about 19% and 14% below the peer averages.
- 11.3x NTM is about 22% below the peers' 5-year average (14.4x) and 16% below their 10-year average (13.5x).
- Against industrials with similar margins, the discount is about 26% (11.3x vs 15.3x) and about 45% (10.4x vs 19.0x).
- The PF multiples imply roughly $1.35bn of LTM EBITDA and $1.24bn of NTM EBITDA. That is about $190-215m above the reported base.

## 2. Why reported parity is not cheap: CI's growth and margin gap (Exhibits 2 and 8)
- **Growth trails peers.** Five-year historical EBITDA growth is 1.9% for CI versus 8.4% for HVAC peers. Two-year forward growth is 3.3% versus 7.2%.
- **Revenue grew, but not profit.** CI's 5-year revenue growth (5.2%) beats peers (2.1%), but this has not reached EBITDA.
- **Margins have shrunk.** Adjusted EBITDA margin fell from 27.3% (2017) to 23.2% (2022E). Gross margin fell from 37.1% to 31.1%. This points to lost pricing power and cost inflation.
- **Growth-adjusted, CI is expensive.** Dividing the NTM multiple by forward growth gives about 4.1x per point of growth for CI (13.4 / 3.3) versus about 1.8x for peers (13.2 / 7.2).
- **Near-term earnings dip.** Company FG's projections (Exhibit 3) show EBITDA falling from $1,130m to $1,046m in 2023E. The projections carry $41m of incremental standalone and quality-of-earnings costs, plus $98-102m a year of stand-up and one-time costs in 2023-24.
- **Long history of flat EBITDA.** EBITDA was $1,072m in 2017, $1,010m in 2019, $950m in 2020 and $1,090m in 2021, essentially flat for years (Exhibit 2).

On reported numbers, a slower-growing business with shrinking margins arguably deserves a discount to HVAC peers. It is instead priced at parity. The headline price is therefore fair at best.

## 3. Why the pro forma discount is credible
- **The plan to 2027 is mostly within management's control.** The bridge (Exhibit 5) takes EBITDA from $1,130m to $1,614m, about +$484m or a 7.4% annual growth rate, in line with peers' forward growth. Of that increase:
  - Cost-savings initiatives: $148m (31%).
  - Strategic pricing: $105m (22%).
  - SG&A leverage: $72m (15%).
  - Together, $325m, or about two-thirds of the growth, comes from actions management controls rather than market growth.
  - Regional volume growth is $248m (Americas $138m, Europe $42m, AMEA $68m).
  - Offsets are FX (-$50m), eliminations and other (-$68m), and standalone costs (-$6m).
- **Pricing looks recoverable.** The ~6-point gross-margin decline suggests pricing headroom, consistent with CI's leading market positions (Exhibit 1). CI holds the largest share in each segment shown: residential HVAC, Product F (~35%), refrigeration (~40%) and transport (~40%).
- **The savings were checked in diligence (Exhibit 4):**
  - Company EJ and Company ED ran a multi-month operations study with site visits and identified a total cost-savings target.
  - Standalone costs were validated bottom-up.
  - Transition service agreements (TSAs) are in place with a stand-up roadmap.
  - Only a modest quality-of-earnings (CoE) adjustment was needed.
  - A lockbox mechanism means cash generated between signing and closing (-$310m in Exhibit 10) benefits the buyer.
- **The seller shares the risk.** Company BR keeps 40% of the common equity ($1.72bn) and provides a $2.25bn seller note paying 5% in kind (PIK). Company ED's convertible preferred converts at a 10% premium to the deal price. About $3.95bn of the $14.05bn in sources comes from the seller, which shows confidence in the value and aligns incentives.
- **Leverage appears to use the PF figure.** The "~4.0x" senior leverage on $5.5bn of third-party debt only works on PF EBITDA (5.5 / 1.35 = 4.1x). Lenders have effectively accepted the PF number, although on reported LTM EBITDA it is about 4.9x.

## 4. Why the multiple does not need to rise
- **Exit at entry multiple.** On the 2027E EBITDA of $1,614m, exiting at the reported entry multiple of 12.4x gives about $20.0bn of enterprise value, versus $14bn today.
- **Exit at the peer multiple.** At today's peer NTM of 13.2x, value is about $21.3bn.
- **Exit below entry.** Even at the PF entry multiple of 10.4x, value is about $16.8bn.
- **Upside from the gap to peers.** If execution closes the growth and margin gap, CI deserves at least the peer multiple. The peer multiple sits below its own 5-year average (14.4x), and similar-margin industrials trade at 15-19x.
- **Summary.** Value creation comes from EBITDA growth. There is room for the multiple to rise and limited room for it to fall.

## 5. Risks that cap the attractiveness (as of Sept 2022)
- **The PF discount depends on execution.** Paying 10.4x PF means Company ED is paying the seller today for about $200m of improvements it must deliver itself. If only the reported EBITDA materializes, the price is simply at market (12.4x / 13.4x), with no discount for the weaker growth profile.
- **Tougher macro backdrop.**
  - The Fed raised rates 75bp in June, July and September 2022.
  - The "Will Slaying Inflation Require Recession?" source flags substantial recession risk and downside for risk assets.
  - HVAC volumes, pricing and the 2023E dip could all be worse than planned.
  - Floating-rate debt at SOFR+4.50% and SOFR+6.75% becomes more expensive; SOFR was 2.42% on 9/30/22.
- **Exit depends on markets.** The case notes that an IPO exit is highly sensitive to economic conditions. Sector multiples are already below their history and could compress further.
- **Carve-out execution.** Stand-up costs, TSA exits and FX (-$50m in the bridge) all add risk.

## Conclusion
Measured against public HVAC manufacturers, $14bn is an attractive entry price, with one qualification.

- **On a pro forma basis it is attractive.** At 10.4x LTM and 11.3x NTM, it is a 14-19% discount to current HVAC OEM multiples (12.9x / 13.2x). It is about 16-22% below their 10- and 5-year average NTM multiples (13.5x / 14.4x). It is far below similar-margin industrials (19.0x / 15.3x).
- **On a reported basis it is only fair.** At 12.4x / 13.4x it is at parity, while CI's EBITDA growth runs at about half the peers' rate (3.3% vs 7.2%).
- **Why proceed anyway.** The diligenced cost and pricing plan makes the PF figures credible, and seller rollover and financing share the risk. Company ED is buying a market-leading asset without relying on a higher exit multiple.
- **Recommendation.** Proceed at $14bn but do not stretch above it. Protect the PF case through the operating plan and the capital structure, given the rising-rate, recession-risk environment of Sept 2022.

Sources: Exhibits 1, 2, 3, 4, 5, 8, 10; Proposed Deal Structure table; 2022-09 timeline; sources [4] and [5].
