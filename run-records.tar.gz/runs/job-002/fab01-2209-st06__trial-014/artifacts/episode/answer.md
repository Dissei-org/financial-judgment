# Gating diligence workstream for the Company CI carve-out (as of Sept 2022)

## Answer
The **Operations / cost-savings workstream (Company EJ + Company ED)** should be the gating item before Company ED signs. Its output must be tied to the carve-out standalone-cost and stand-up plan. In practice, Company ED should not sign until the identified cost-savings target is:
- converted into a validated, bottoms-up, phased plan with owners and one-time cost-to-achieve;
- reconciled to the standalone-cost and TSA-exit plan, so savings are not double counted against separation dis-synergies;
- stress-tested against the proposed capital structure.

## Why this workstream controls go/no-go

**1. It is the only material workstream not actually validated (Exhibit 4).**
- Finance/Accounting: complete, with a modest QoE adjustment and lockbox mechanics finalized.
- Tax: complete.
- HR: complete, covering pension, unions, executive comp and HR capabilities.
- IT & Cyber: complete (PwC).
- Carve-Out: bottoms-up validation of management standalone costs; personnel identified; TSAs in place; stand-up roadmap.
- Operations: the multi-month study only "identified total cost-savings target." That is a target, not a validated, time-phased, costed plan.

The open item is exactly where the equity case sits.

**2. The investment thesis depends on it (Exhibit 5, EBITDA bridge).**
- EBITDA grows from $1,130M (2022) to $1,614M (2027E), i.e. +$484M.
- Cost Savings Initiatives are the single largest driver: +$148M, or 31% of growth.
- Strategic Pricing adds +$105M (22%) and SG&A leverage +$72M (15%).
- Roughly two-thirds of the value creation is self-help and margin action rather than volume.
- The headwinds are already visible: incremental elims/other -$68M, FX -$50M, and only -$6M of standalone costs in the bridge.
- Exhibit 3 projections are labelled "Adj. EBITDA (Post-Cost Initiatives)" and show margin rising from 22.8% (2023E) to 27.5%.
- That 27.5% is above the 23-27% range CI achieved historically (Exhibit 2: 23.2% in 2022E, 24.4% in 2021A, peak 27.3% in 2017A).
- Without the savings, the plan reverts to a business that grew EBITDA only from $678M (2007) to $1,090M (2021). Its history is cyclical: -12% EBITDA in 2009, -7% in 2019 and -6% in 2020.

**3. The capital structure leaves little room for savings to slip (Table 1, Exhibit 10, Exhibit 3).**

*Debt package*
- $5.5BN of all-senior, floating-rate debt:
  - $2.9BN TLA at SOFR+450, stepping up 50 bps a year from year 3, 97.5 OID;
  - $2.6BN direct loan at SOFR+675, 96.6 OID.
- The TLA has a 1st Lien Net Leverage covenant below 6.5x.
- On top of that sit a $2.25BN 5% PIK seller note and $2.0BN of 7% PIK convertible preferred, both compounding.

*Leverage*
- Senior debt is about 4.7x 2022E Adj. EBITDA ($1,175M).
- It is about 5.3x 2023E ($1,046M), because 2023E EBITDA already dips once standalone costs and QoE adjustments are burdened.
- EBITDA only needs to fall to roughly $840M before the 6.5x covenant is at risk. That is about 20% below 2023E, versus a 12% EBITDA drop in 2009.

*Cash flow*
- At 30-day SOFR of 2.42% (9/30/2022), cash interest is about $200M (TLA) + $238M (direct loan), roughly $438M.
- The Fed had just delivered consecutive 75 bp hikes (June, July, Sept 2022), so this is rising.
- 2023E cash flow, roughly:
  - EBITDA $1,046M;
  - less capex $370M;
  - less stand-up/one-time costs $102M;
  - less cash interest about $438M;
  - less cash taxes at 35%, about $150M+;
  - plus a working-capital release of about $60M.
- That leaves only a few tens of millions of free cash flow before amortization. Amortization steps up to 2.5% on the TLA from year 2.
- Every +100 bps of SOFR costs about $55M a year.

*Implication*
- Deleveraging, covenant headroom and the ability to service the PIK layers all depend on the $148M of savings arriving on time and net of cost-to-achieve.
- If they slip or are consumed by dis-synergies, equity (Company ED $2.55BN common plus $2.0BN preferred) absorbs the hit first.

**4. It links directly to the carve-out risk.**
- Standalone costs appear small: $41M of incremental standalone and QoE burden (Exhibit 3 note) and -$6M in the bridge.
- Stand-up/one-time costs of about $80-100M a year run through 2028E.
- In a carve-out, separation dis-synergies and TSA exit costs are where cost-savings plans most often get double counted or offset.
- The Carve-Out workstream validated management's standalone assumptions. But the go/no-go question is whether the net savings survive once CI stands alone.
- That reconciliation belongs to the operations workstream.

**5. Macro and financing context raises the bar (Exhibits 6, 7, 9; Sources 4, 5).**
- High PCE inflation and an aggressive Fed path raise input, labor and rate costs.
- Leveraged loan markets have tightened sharply from the Q1 2021 record ($228BN).
- Recession risk is openly debated.
- In this setting, pricing (22% of the bridge) and cost actions both carry more execution risk, and there is less financing flexibility to fix a miss after close.

## Recommendation
Treat Operations / cost-savings validation, reconciled with the carve-out standalone and TSA plan, as the signing gate. Before signing, Company ED should require:
1. **Initiative-level plan.** A bottoms-up plan with timing, owners and one-time costs, showing whether the $148M run-rate is achievable by 2027 and what is captured by 2023-2024.
2. **Downside cases.**
   - A case with 50% or delayed savings and flat pricing.
   - A 2009-style downturn.
   - Higher SOFR.
   - Each tested against the 6.5x covenant, free cash flow after amortization, and PIK accretion.
3. **Protections if validation is weak.**
   - Re-price the deal.
   - Resize debt or equity.
   - Seek more seller support, such as a larger or more subordinated seller note.
   - Or walk away.

The other workstreams (finance/QoE, tax, HR, IT/cyber, carve-out/TSA) are reported complete and are confirmatory rather than gating.

*Based only on materials dated on or before September 2022. Figures are from Exhibits 2-5, 10, Table 1 and the Fed/inflation sources; cash-flow math is approximate.*
