# Diagnosis of Company CI's recent margin pressure (as of 2021-12)

**Bottom line:** The recent margin decline is a fixable pricing-mechanism problem, not structural deterioration. The case materials say margins fell over the past two years *primarily because Company CI's long-term contracts with OEMs had infrequent price-adjustment terms* (Exhibit 2 case note, company documents). Costs moved while contract prices stayed fixed until the next reset, so the company absorbed the gap. This is a timing and contract-terms issue. It is not evidence of eroding competitive position, weak demand, or a broken business model. A buyer should treat it as a value-creation lever (commercial and pricing excellence), not a reason to lower the valuation.

## What the numbers show (Exhibit 2, $M)
| | 2017 | 2018 | 2019 | 2020 | 2021 |
|---|---|---|---|---|---|
| Revenue | 3,925 | 4,182 | 4,068 | 3,758 | 4,460 |
| Gross margin | 37.1% | 35.1% | 33.9% | 34.9% | 33.2% |
| Adj. EBITDA | 1,072 | 1,086 | 1,010 | 950 | 1,090 |
| Adj. EBITDA margin | 27.3% | 26.0% | 24.8% | 25.3% | 24.4% |

- The compression is **modest and gradual**: about 390 bps of gross margin and about 290 bps of EBITDA margin from the 2017 peak. It is not a collapse.
- 2021 margins (33.2% GM, 24.4% EBITDA) remain **well above 2007-2009 levels** (27.8-29.7% GM, 20.9-22.3% EBITDA). The long-run expansion story holds.
- Demand is strong. 2021 revenue rose **+18.7% to a record $4.46B**, and Adj. EBITDA rose **+14.7% to a record $1,090M**. Volume is not the problem. The pattern is revenue up, margin rate down, which is what happens when prices are locked while costs move.

## Why it is not a competitive-position problem (Exhibit 1)
Company CI is the clear share leader in every segment: about **70% of Residential HVAC**, about **35% of Product F**, about **40% of Refrigeration**, and about **40% of Transport**. It is several times the size of the next competitor in most segments. A leader with this share should have pricing power. Margin leakage alongside that share points to contract terms (lagged price resets with OEM customers), not customers switching or competitors undercutting.

## Implications for the carve-out investment case
1. **Addressable lever:** When the OEM contracts come up for renewal, renegotiate them with more frequent price resets and/or cost pass-through or indexation clauses (e.g., raw-material escalators). This should recover much of the lost margin toward the historical 25-27% EBITDA range.
2. **Carve-out angle:** Under its former parent the business may not have prioritized commercial and pricing discipline. A focused, stand-alone owner can make pricing a core management priority.
3. **Diligence items and risks:**
   - Map the OEM contract book: remaining terms, renewal dates, reset frequency, and any existing pass-through clauses. This sets how fast margin can recover.
   - Test OEM bargaining power and the risk of share loss if Company CI pushes price. The OEMs are concentrated, sophisticated buyers.
   - Check whether cost pressure worsens before the resets. With fixed-price terms, any further input-cost rise would hit margins again in the near term.
4. **Underwriting:** Base-case projections should not simply extrapolate the 2021 margin downward. They also should not assume instant recovery. Model a phased recovery tied to the contract renewal schedule, with a downside case if repricing is only partly achieved.

## Context (not the cause)
- Financing conditions at the anchor were supportive. U.S. leveraged-loan issuance hit a record of about $228B in 1Q21 (Exhibit 9 and timeline), and a leadership change at Company BR catalysed carve-out discussions.
- The macro inflation series in Exhibit 6 is not the case's stated driver. Taken alone, it does not explain a slide that began in 2018. The case specifically attributes the recent decline to infrequent price adjustment in long-term OEM contracts.

**Diagnosis:** The margin decline is temporary and commercially driven, caused by lagged OEM contract pricing. It sits on top of a structurally strong, share-leading business. It is a fixable issue and a potential upside lever for the new owner. Diligence should confirm the contract renewal timeline and the company's ability to reprice.
