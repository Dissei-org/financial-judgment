# Company CI carve-out: if Company BR had refused to roll equity or take a seller note (as of 2022-09)

## 1. What Company BR provides today
Uses total $14,052M: $14,000M purchase price, $362M fees and expenses, less $310M of lockbox cash from sign to close (Exhibit 10).

| Source | $M | Terms | Provider |
|---|---|---|---|
| Third-party senior debt | 5,500 | $2.9B TLA at SOFR+450 (97.5 OID, step-ups from yr 3, 1st-lien net leverage < 6.5x) and $2.6B direct loan at SOFR+675 (96.6 OID) | Banks / private credit |
| Seller note | 2,250 | 5% PIK, senior to the preferred | **Company BR** |
| Convertible preferred | 2,000 | 7% PIK, converts at 10% premium, priority sell-down after an IPO | ED + co-invest |
| Common (60%) | 2,581 | | ED + co-invest |
| Rolled common (40%) | 1,721 | | **Company BR** |

Company BR therefore supplies about **$3.97B, roughly 28% of total capital and 47% of everything junior to the senior debt**. Company ED plus co-investors write $4.58B.

Backdrop for the counterfactual:
- 2022 EBITDA is about $1,130M (Exhibit 5), so the $14B price is 12.4x LTM, or 10.4x pro forma for cost actions (Exhibit 8).
- Senior debt of $5.5B is about 4.0x pro-forma EBITDA and about 4.9x reported.
- Total debt including the seller note is already about 5.8x PF and 6.9x reported.
- Institutional leveraged-loan volume collapsed from $184B in 1Q21 to $22B in 3Q22; banks were the marginal supplier at $56B (Exhibit 9).
- The Fed had hiked 75bp in June, July and September. Dealers expected a fed funds rate of about 4.4% by end-2022, and the dot plot centred on 4.1 to 4.4% (Exhibit 7; NYT, Sept 2022).

## 2. How Company ED would have had to reshape the stack to hold $14B
Company ED would need to replace about $4.0B of patient, cheap, junior capital, and slightly more once extra OID and fees are added.

### Option A: replace it with more third-party debt (largely not feasible)
**Leverage.**
- Taking all $7.75B of debt to the market puts third-party leverage at about 5.8x PF and about 6.9x reported EBITDA.
- That is essentially at or through the 6.5x first-lien covenant on day one if lenders do not credit the cost savings.

**Pricing.**
- Today's cash coupons are about 6.9% on the TLA and about 9.2% on the direct loan, using SOFR of 2.42%.
- On the forward curve (SOFR about 4.4%) these become about 8.9% and 11.2%. Senior cash interest rises from about $440M to about $550M.
- Another $2.25 to 4.0B of incremental direct-lending or second-lien debt at 11 to 13%, with 96 OID, adds roughly $250 to 500M of cash interest.
- Total cash interest would approach $0.8 to 1.0B against $1.1 to 1.35B of EBITDA. Interest coverage falls to about 1.2 to 1.6x, before capex, taxes, pension and carve-out costs.

**Capacity.**
- The institutional market that would have to absorb this is running at about 12% of its 2021 pace.

**Conclusion.** At most a small increment of incremental debt, perhaps $0.5 to 1.0B of unitranche or HoldCo paper, is plausible. It could not replace the full $4B.

### Option B: equity-heavy restructuring (the realistic core)
Keep the senior debt at $5.5B and about 4x. Company ED and co-investors fill the gap:
- **Sponsor-side equity rises from $4.58B to about $8.5 to 8.6B**, roughly 1.9x the current check and about 61% of capitalization, versus 33% today.
- Company ED owns 100% of the common.
- Product X ($26.2B, 2019) cannot prudently hold a single $8B+ position; $4.58B is already about 17% of the fund. That forces a much larger co-investment syndication, a club deal with another sponsor, or LP co-invest sleeves. Each costs time, governance control and certainty of close.

### Option C: hybrid, the most likely answer
- Keep $5.5B of senior debt.
- Add $1.5 to 2.0B of third-party structured capital, such as a HoldCo PIK note or preferred from private credit or structured-equity funds. In September 2022 this would price at about 11 to 14% PIK plus fees or warrants, versus the seller's 5%. Because it sits behind the senior debt, the senior 6.5x covenant is protected, but the PIK compounds fast.
- Increase ED and co-invest common by about $2.0 to 2.5B.
- Protect the headline price with price-neutral mechanics, for example:
  - an earnout or contingent consideration tied to delivery of the $148M cost-savings and $105M pricing buckets in the EBITDA bridge;
  - tighter TSA and standalone-cost protections;
  - specific indemnities, or reps and warranties insurance.
- Push harder on the lockbox and on BR leaving cash on the balance sheet (currently $50M).

### Economic, not just headline, price
The 5% PIK seller note is below-market paper.
- Illustration: it accretes to about $3.2B over 7 years (2.25 x 1.05^7). Discounted at a September-2022 junior-credit rate of about 12%, that is worth only about $1.4 to 1.5B.
- Company BR is therefore implicitly giving about $0.7 to 0.8B of value back. The economic price is closer to $13.2 to 13.3B than $14B.
- If BR refuses, Company ED pays a true $14B in market-priced capital. Closing at the same price is effectively a price increase of about 5 to 6% to Company ED. In a rising-rate market with falling multiples, that would argue for a price cut or earnout rather than simply writing a bigger cheque.

## 3. How risk-sharing shifts
**Today, the seller is a first-loss partner.**
- BR's $1.72B of common sits below $5.5B of senior debt, its own note, and ED's 7% PIK preferred, which also has priority sell-down after an IPO.
- BR's note is subordinated to the senior debt and PIK, so BR carries credit risk on about $2.25B with no cash yield.
- BR is effectively funding the downside cushion beneath Company ED's preferred.

**Information and execution alignment.**
- The rollover signals that the seller believes in the standalone plan: TSAs, standalone costs (-$6M in the bridge), cost savings (+$148M), pricing (+$105M), and regional growth.
- Without it, Company ED bears 100% of carve-out execution risk. It also loses a motivated partner for TSA delivery, customer and supplier continuity, and management retention.
- Lenders and co-investors would read the absence of a rollover as a negative signal, which worsens debt terms further.

**Concentration of downside at Company ED.**
- Dollar exposure roughly doubles, from about $4.6B to about $8.5B.
- Illustrative, ignoring free-cash-flow deleveraging: at a 10x exit on about $1.6B of 2027E EBITDA, ED's MOIC is about 1.3x in both structures, but the capital at risk nearly doubles.
- In a real downside (recession, as the Company DC research flags, with multiple compression), there is no seller layer below the preferred to absorb losses.
- If Option A were used instead, the risk shifts to lenders and to default probability. Thin coverage and a covenant near 6.5x mean a modest EBITDA miss could trigger a breach. Default and refinancing risk rise sharply, particularly with the TLA step-ups from year 3 and floating rates.

**Upside and control.**
- Company ED would keep 100% of the equity upside, full governance, and cleaner IPO and exit mechanics, with no 40% strategic holder and no seller-note overhang.
- Returns are diluted by the larger check at the same price, so IRR falls.
- Replacement structured capital (11 to 14% PIK) takes a larger share of value than BR's 5% note, transferring value from common equity to third-party capital providers.

**Seller's position.**
- BR gets more cash at close, about $4B more, and a clean exit.
- BR forgoes 40% of the upside, including any IPO re-rating toward peer multiples of about 13 to 15x NTM.
- In return for that liquidity, BR would reasonably be expected to accept a lower price. That is why holding $14B would be difficult to justify.

## 4. Bottom line
Without BR's $3.97B, the deal only closes at $14B through a much more equity-heavy structure: roughly $8.5B of sponsor and co-invest money, likely requiring a club or large co-invest, plus possibly $1.5 to 2B of expensive structured HoldCo capital. More senior debt is not a realistic substitute. The September 2022 loan market was shut for institutional volume, SOFR was heading above 4%, and leverage would breach about 6 to 7x against a 6.5x covenant.

Risk-sharing flips from a structure where the seller holds a subordinated, below-market, first-loss position to one where Company ED concentrates the carve-out execution, macro and multiple risk. The lost 5% PIK subsidy of about $0.7 to 0.8B means the same headline price is a materially higher economic price. Company ED would therefore rationally push for a lower price, an earnout, or stronger TSA and indemnity protections rather than simply absorbing the gap.
