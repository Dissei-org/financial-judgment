# Company CI relative market position (as of 2022-06)

## Bottom line
The segment-share exhibit (Exhibit 1, 'Company CI (as of 2021)', source: company documents) shows Company CI is the clear #1 player in all four segments it competes in. Its share is roughly 2x to 5x that of its largest named competitor in each. Its competitors are fragmented and none is close to its scale in any segment. CI is a scaled segment leader with strong relative market share. That position is most dominant in Residential HVAC and most contested in Transport.

## Evidence from Exhibit 1 (2021 shares)
| Segment | Company CI | Largest named rival | Relative share (CI / #2) | Rest of market |
|---|---|---|---|---|
| Residential HVAC | 70% | LG 13% (Rechi 2%) | ~5.4x | Other 15% |
| Product F | 35% | Company J 9% (Other Captive 10% in aggregate; EU 7%, FA 6%, EN 5%) | ~3.9x | Other 28% |
| Refrigeration | 40% | Company EN / EV / BE, 10% each | ~4.0x | Other 30% |
| Transport | 40% | Company Z 20% (Company J 10%) | ~2.0x | Other 30% |

Key observations:
- **Leader everywhere.** CI holds the largest share in every segment. It holds a majority (70%) in Residential HVAC and 35-40% elsewhere.
- **No rival of comparable scale.** The next-largest named player holds 2-20%. Company EN appears in both Product F and Refrigeration, and Company J in both Product F and Transport. Neither exceeds 10% in any segment, so no single competitor matches CI's breadth across segments.
- **Fragmented tails.** 'Other' makes up 15-30% of each segment, which suggests many small players rather than a strong challenger.
- **Weakest relative position: Transport.** Company Z at 20% is half of CI's share. This is the one segment where a credible #2 exists and competitive pressure is most likely.
- **Strongest: Residential HVAC.** A 70% share is near-dominant. This implies pricing power and installed-base advantages, but also little room for further share gains.

## Consistency with financials (Exhibit 2)
The leadership position fits CI's economics:
- Gross margins stayed in a tight 28-37% band from 2007 to 2021 (33.2% in 2021).
- Adj. EBITDA margins were roughly 21-27% (24.4% in 2021, on EBITDA of $1,090M and revenue of $4,460M).
- The business held up in downturns:
  - 2009: revenue fell 15.3%, yet EBITDA margin rose to 22.3%.
  - 2020: revenue fell 7.6%, yet EBITDA margin was 25.3%.
- These patterns are typical of a scale leader with pricing power and a large installed or aftermarket base.
- However, revenue grew only about 2.3% per year from 2007 to 2021 ($3,242M to $4,460M). High shares in mature segments mean growth depends mainly on market growth, pricing, and adjacencies, not on taking share.

## Implications for the carve-out
The context is a carve-out, with Company ED as a private equity sponsor and carve-out talks sparked by the 2021 CEO change at Company BR.
- Leading, defensible positions support stable, predictable cash flows. That helps leverage capacity, which matters given record leveraged-loan issuance in 2021 and the Fed's 75bp hike in June 2022, which raised the cost of debt.
- The value-creation thesis is more likely to rest on operational improvement, pricing, and margin protection than on share gains.
- High shares, especially 70% in Residential HVAC, could limit in-segment bolt-on M&A because of antitrust risk.

## Caveats
- Shares come from company documents, are round numbers, and use segment definitions chosen by the company. Narrow definitions can inflate share.
- The exhibit is a single 2021 snapshot. It shows no trend, so we cannot tell whether CI is gaining or losing share.
- The segments are not sized in dollars. The weight of each segment in CI's $4.46B of revenue is unknown.
- 'Other' and 'Other Captive' are aggregates. They could hide one mid-sized player, but none is shown as close to CI.

**Conclusion:** Exhibit 1 implies Company CI is the dominant, scale market leader across its segments, with relative market share of about 2-5x its nearest competitor. That is a strong competitive position for a carve-out. The main watch-points are Transport, where Company Z holds half of CI's share, and limited room for further share-driven growth.
