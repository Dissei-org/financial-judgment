# Would Company CI be relatively resilient if demand weakened after 2021-12?

**Short answer: Yes, relatively resilient at the operating level. Revenue would fall, but EBITDA would likely fall by less and margins would hold. The main exceptions are that 2021 looks like a peak-cycle year with already-compressed gross margin, and that the resilience of a highly levered carve-out's equity is a separate and weaker question.**

## 1. Track record through two real downturns (Exhibit 2)

| Episode | Revenue | Adj. EBITDA | EBITDA margin | Recovery |
|---|---|---|---|---|
| 2009 (GFC) | -15.3% (3,449 to 2,921) | -12.2% (740 to 650) | rose from 21.5% to 22.3%; gross margin rose from 28.4% to 29.7% | 2010 revenue of 3,466 beat 2008; EBITDA +39.5% to 907 |
| 2020 (COVID) | -7.6% (4,068 to 3,758) | -5.9% (1,010 to 950) | rose from 24.8% to 25.3%; gross margin rose from 33.9% to 34.9% | 2021 revenue of 4,460 and EBITDA of 1,090 were record highs |
| 2012 / 2015-16 soft patches | -5.6% / -2.1%, -1.3% | -4.4% / -2.2%, then +5.2% | held at about 25-27% | quick |

- **Decremental margins were below the average margin.** In 2009 EBITDA fell about 90 on a revenue drop of about 528, a decremental of about 17% against a 21.5% margin. In 2020 EBITDA fell about 60 on a revenue drop of about 310, a decremental of about 19% against a 24.8% margin. This points to a flexible cost base and pricing that held up.
- **EBITDA never had a loss year.** Its trough in 2009 was still 650, and it compounded from 678 in 2007 to 1,090 in 2021, about 3.4% a year, against revenue growth of about 2.3% a year.

## 2. Structural reasons (Exhibit 1, plus inference)

- **Leading shares in every segment:** about 70% of Residential HVAC (well ahead of LG at about 13%), about 35% of Product F, about 40% of Refrigeration and about 40% of Transport. Scale and a leadership position support pricing power and distribution access in a downturn.
- **Replacement demand (inference):** residential HVAC and refrigeration demand is largely non-discretionary replacement of failed units, which tends to cushion volume. The dataroom does not quantify the replacement/aftermarket mix; my grep found no such data, so treat this as reasoning rather than a case fact.
- **Experienced management:** the leadership source (source 3) describes a team with long HVACR and industrial experience.

## 3. Why resilient does not mean immune

- **2021 is a rebound base.** The 18.7% revenue growth in 2021 likely includes recovery and possibly pull-forward. A downturn measured from 2021 could look worse than the long-run pattern suggests.
- **Margins were already under pressure.** Gross margin fell from 37.1% in 2017 to 33.2% in 2021, and EBITDA margin fell to 24.4% in the strongest revenue year. That suggests cost pressure the company had not fully passed through, which leaves less cushion than in 2009 or 2020.
- **2019 was an exception.** EBITDA fell 7.0% on only a 2.7% revenue decline, and from 2018 to 2020 EBITDA fell about 12.5% against a revenue drop of about 10%. Mix and cost can hurt even in mild slowdowns.
- **Transport is more cyclical.** Truck and trailer refrigeration follows freight and fleet capex, so it is the segment most exposed.
- **Capital structure risk.** Exhibit 9 and the timeline show record leveraged loan issuance: about $228B in 1Q21 and about $170-230B per quarter through 2021. That points to an aggressive buyout financing. At high leverage, even a 10-15% EBITDA decline, similar to 2009, would tighten covenants and coverage. So operational resilience does not guarantee equity returns.
- **Carve-out execution.** Stand-up costs and separation from the parent could reduce cost flexibility in the first years.

## Conclusion

Based on the evidence available at 2021-12, I would expect Company CI to be relatively resilient, and more resilient than typical industrial cyclicals. The evidence is two recessions with high-single to low-double-digit EBITDA declines, stable or rising margins, recovery within about a year, and dominant market shares. An investor should still stress-test a peak-to-trough EBITDA decline of about 10-15%, similar to 2009, from a 2021 base whose margins were already compressed. Leverage should be sized so the business can carry that decline, rather than assuming 2021 performance continues.
