# Why Company CI’s recent margin pressure mattered at the 2022-06 anchor

At the June 2022 anchor, Company CI’s margin pressure was central to the investment case—not merely a minor operating blemish—because it affected the level and quality of the EBITDA on which a carve-out would be valued, financed, and underwritten.

## What the visible financial evidence showed

Company CI’s 2021 revenue recovered strongly, but profitability did not keep pace:

- Revenue rose from **$3,758 million in 2020 to $4,460 million in 2021**, up **18.7%**.
- Adjusted EBITDA rose from **$950 million to $1,090 million**, up only **14.7%**.
- Gross margin therefore fell from **34.9% to 33.2%**, and adjusted EBITDA margin fell from **25.3% to 24.4%**.
- The 2021 margins were also below the earlier peak shown in the financial history: 2017 gross margin was **37.1%** and adjusted EBITDA margin was **27.3%**.

Thus, the top line was recovering, but incremental sales were not converting into profit at the historical rate. The issue was material enough to change the earnings base used in a transaction: on 2021 revenue, every **100 basis points** of EBITDA margin represented about **$44.6 million** of EBITDA before applying any transaction multiple.

## Why the cause was important

The case evidence gives a specific explanation: Company CI’s margins had declined primarily because it operated under **long-term contracts with original equipment manufacturers (OEMs) that contained infrequent price-adjustment terms**. In other words, the immediate evidence pointed to a contract/pricing-reset lag rather than to an obvious loss of customer demand.

That distinction was critical for the investment case:

- If the pressure was temporary, reported 2021 EBITDA may have understated a normalized earnings level, creating potential value for a buyer able to bridge the pricing lag.
- If contractual repricing was slower than expected, or costs remained elevated, the lower margin could persist and the deal would be based on a structurally lower earnings base.
- Consequently, the buyer could not simply extrapolate 2021 revenue growth. It had to underwrite contract reset timing, customer terms, input-cost trajectory, and management’s ability to restore margin without losing OEM volume.

Company CI’s market positions made this a question of execution and timing rather than automatic evidence of franchise damage: Exhibit 1 shows approximate leading shares in its major 2021 end markets, including roughly **70% in Residential HVAC**, **35% in Product F**, and **40% each in Refrigeration and Transport**. But those strong positions did not eliminate the near-term constraint—the OEM contract structure limited how quickly pricing could respond.

## Why this mattered more in the June 2022 deal environment

The margin issue also intersected with a much more difficult financing market. The leveraged-loan exhibit shows non-bank institutional volume collapsing from **184 in 1Q21 to 56 in 2Q22**, while the total shown volume fell from approximately **227 to 134**. The case evidence explicitly says Company ED had to mitigate fundamental risks while overcoming a **severe scarcity of high-yield debt capital**. The rate environment was also tightening by mid-2022.

Lower current margins therefore had a amplified impact: they reduced cash generation and debt capacity precisely when lenders were less available and more risk-sensitive. Any delay in margin recovery increased financing complexity, price risk, and sensitivity to a further cost or demand shock.

## Investment-case conclusion

Recent margin pressure mattered because it determined whether Company CI was a high-quality franchise with temporarily depressed, contract-constrained EBITDA or a business whose recoverable earnings were structurally lower. That question affected entry valuation, the credibility of the base case, the amount of leverage the transaction could support, and the structure required to survive a delayed recovery.

At the 2022-06 anchor, the prudent conclusion was not to assume either automatic recovery or permanent impairment. The investment case depended on proving, from the contracts and contemporaneous operating data, that pricing resets and cost actions could restore margin before the pressure materially impaired cash flow—and on structuring the carve-out for the possibility that recovery took longer than planned.
