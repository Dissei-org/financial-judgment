# Recommendation: gate signing on carve-out readiness

As of the September 2022 signing decision, Company ED should treat the **dedicated Carve-Out diligence workstream**—validation of the standalone operating model, transferred personnel, transition-services arrangements, and function stand-up roadmap—as gating before signing.

This is not merely another accounting, tax, HR, IT, or operations checklist item. It is the workstream that determines whether Company CI can actually operate as an independent company on economic assumptions consistent with the deal model.

## Why this should control go/no-go

**1. The deal thesis depends on a credible standalone model.**  
The carve-out diligence report states that Company ED and Company EJ performed detailed bottoms-up work to:

- validate management’s standalone cost assumptions;
- identify the specific personnel moving with the carve-out; and
- put TSAs in place and establish a roadmap to stand up all necessary functions in the new organization.

Those are day-one viability issues. If the perimeter, people, systems, contracts, or services are incomplete, Company CI may face stranded costs, service interruption, or a slower/more expensive stand-up after signing.

**2. The financial projections are explicitly burdened by separation.**  
The projections include **$41 million of incremental standalone costs** and quality-of-earnings adjustments not reflected in the historical financials. They also assume annual minority-interest/stand-up/one-time costs of approximately **$77–102 million from 2023 through 2028**. Consequently, small errors in TSA pricing, duration, scope, or timing directly affect free cash flow and returns.

The EBITDA bridge reinforces execution risk: the model grows from **$1.13 billion of 2022 EBITDA to $1.614 billion in 2027E**, relying on pricing, SG&A leverage, and **$148 million of cost-savings initiatives**, while standalone costs and eliminations are negative bridge items. A carve-out plan that is not operationally executable undermines both the operating case and the amount Company ED can prudently pay.

**3. The capital structure leaves limited room for separation mistakes.**  
The proposed transaction values Company CI at approximately **$14 billion** and uses **$5.5 billion of third-party senior debt**, a **$2.25 billion 5% PIK seller note**, and **$2.0 billion of 7% PIK convertible preferred equity**. The senior debt is floating rate. This makes forecast EBITDA, cash interest, stand-up costs, and TSA payments especially important. Unbudgeted stranded costs or delayed stand-up would affect leverage, liquidity, and returns.

The market context also argued for a hard gate rather than deferring unresolved issues: the Federal Reserve had already made 75-basis-point increases in June and July 2022, while institutional leveraged-loan issuance had fallen sharply from the 2021 peak. At the September table, Company ED could not assume that a signing mistake could easily be repaired through later financing flexibility.

## Signing gate

Before signing, Company ED should require reasonable assurance that:

1. the legal/perimeter and day-one operating model are complete;
2. TSA scope, pricing, service levels, duration, and exit ramps are sufficiently defined;
3. key personnel and required corporate capabilities are confirmed;
4. the recurring standalone-cost estimate and one-time stand-up budget are validated; and
5. shared contracts, systems, licenses, facilities, and services can move or be replaced without material disruption or unbudgeted cost.

Finance/accounting, tax, HR, operations, and IT/cyber diligence are important and largely reported as complete, but their findings have to come together in the carve-out readiness assessment. **Therefore, carve-out/separation readiness should be the gating workstream: if it cannot be validated, Company ED should not sign on the proposed terms—or should delay/reprice until the standalone model and execution plan are demonstrably credible.**
