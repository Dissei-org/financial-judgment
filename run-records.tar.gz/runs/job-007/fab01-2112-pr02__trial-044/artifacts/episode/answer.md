# Company CI demand-resilience assessment (as of December 2021)

## Conclusion: qualified yes
As of the December 2021 anchor, I would expect Company CI to be **relatively resilient at the operating-profit level if demand weakened**, but it should not be underwritten as recession-proof. The evidence supports better-than-average downside durability, not immunity from a fall in volume.

## Supporting evidence

**1. Strong competitive positions across several product/end-market categories**

The 2021 market-share exhibit places Company CI at approximately:

- **70%** in Residential HVAC;
- **35%** in Product F;
- **40%** in Refrigeration; and
- **40%** in Transport.

That kind of market leadership normally provides scale, distribution reach, and a stronger competitive position than a marginal supplier would have during a downturn. The presence in four named categories also reduces single-product exposure, although the exhibits do not disclose their respective revenue weights or demand correlations.

**2. Prior downturns showed profit-margin resilience even when revenue fell**

The historical financials provide two direct pre-anchor stress observations:

| Stress year | Revenue change | Gross margin | Adjusted EBITDA change | Adjusted EBITDA margin |
|---|---:|---:|---:|---:|
| 2009 | **-15.3%** | 28.4% to **29.7%** | **-12.2%** | 21.5% to **22.3%** |
| 2020 | **-7.6%** | 33.9% to **34.9%** | **-5.9%** | 24.8% to **25.3%** |

In both cases, adjusted EBITDA fell by less than revenue and margins expanded. Gross margin also held up. That is evidence of a durable cost/mix profile, pricing discipline, and/or successful cost responses. Earlier declines in 2012 and 2019 were also modest, while 2021 revenue and EBITDA rebounded strongly to $4.46 billion and $1.09 billion, respectively.

**3. Management depth adds incremental support**

The company leadership source describes a global team with **375 years of combined experience** and proven records leading public, industrial, and HVACR businesses. That does not create demand immunity, but it increases confidence in execution during a weaker demand environment.

## Limits and risks

- The business was **not revenue-immune**: revenue fell 15.3% in 2009 and 7.6% in 2020. Residential HVAC and related equipment purchases can likely be deferred in a weak economy.
- Market share does not reveal how much revenue was recurring, contractual, aftermarket, or backed by backlog; the visible materials do not provide those details.
- The relative contribution and cyclicality of Residential HVAC, Product F, Refrigeration, and Transport are not disclosed, so the four categories cannot be assumed to be equally weighted or uncorrelated.
- No balance sheet, cash-flow, liquidity, customer-contract, or leverage information is provided. Consequently, this conclusion concerns **operating resilience**; a leveraged carve-out capital structure could still make the equity materially riskier in a downturn.

## Overall assessment

Company CI looks **more resilient than a typical cyclical equipment business**: it had very strong market positions, exposure to multiple categories, experienced HVACR/industrial leadership, and a demonstrated ability to preserve gross and EBITDA margins through the 2009 and 2020 demand shocks. I would therefore expect adjusted profitability to hold up better than revenue in a moderate downturn. The appropriate expectation is **relative resilience with cyclical revenue risk**, not complete protection from a severe demand contraction.
