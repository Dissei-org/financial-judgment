# Company CI: Is a $14 billion entry price attractive?

## Recommendation

**Yes—but the price is only moderately attractive, not a clear bargain.** At $14 billion, Company CI is broadly priced like the average publicly traded HVAC OEM on reported near-term EBITDA, but below them on LTM EBITDA, below their longer-run trading averages, and meaningfully below them on the case's pro forma basis. The value-creation case therefore depends heavily on delivering the diligenced margin-recovery plan. I would support proceeding at $14 billion, but would not characterize it as a deep-discount entry and would not stretch the price further without more verified EBITDA.

## Comparison with public HVAC manufacturers

Exhibit 8 calculates CI's multiples at the assumed **$14 billion purchase price**, with LTM/NTM periods centered on FYE 9/30/22:

| Benchmark | Company CI at $14bn | Public HVAC OEM average | Interpretation |
|---|---:|---:|---|
| Current LTM EBITDA | **12.4x reported / 10.4x PF** | **12.9x** | CI is about 4% below the peer average on reported EBITDA and about 19% below on the presented PF basis |
| Current NTM EBITDA | **13.4x reported / 11.3x PF** | **13.2x** | CI is essentially at the peer average on reported NTM EBITDA, but about 14% below on the PF basis |
| Five-year average NTM EBITDA | n/a | **14.4x** | Current entry is below where those stocks have traded on average over five years |
| Ten-year average NTM EBITDA | n/a | **13.5x** | Current HVAC average is close to CI's current reported NTM multiple |

The EBIT multiples tell a similar story: CI is **14.7x reported / 11.9x PF LTM EBIT** versus **16.2x** for HVAC OEMs, and **15.8x reported / 13.0x PF NTM EBIT** versus **15.2x**. HVAC OEMs have also traded at **16.8x** and **15.6x** NTM EBIT on five- and ten-year averages, respectively.

The reported EBITDA denominators are supported by the case financials. Exhibit 5 shows **2022 EBITDA of $1,130 million**, making $14,000 million equal to **12.4x**. Exhibit 3 shows **2023E adjusted EBITDA of $1,046 million**, making the same price **approximately 13.4x** NTM. Applying the current HVAC LTM multiple to CI's $1,130 million would imply about **$14.6 billion**; applying the current HVAC NTM multiple to $1,046 million would imply about **$13.8 billion**. Thus, the reported-EVIDDA comparison is best described as **market-level**: a modest LTM discount, a modest NTM premium, and no meaningful headline cushion.

## Why the price can still be attractive

The stronger argument comes from CI's business quality and recovery potential:

1. **CI has valuable market positions.** Exhibit 1 shows leading reported positions across its major markets: 70% in Residential HVAC, 35% in Product F, 40% in Refrigeration, and 40% in Transport. This is not a distressed, subscale business.

2. **Revenue growth has been better than the HVAC peer average.** Exhibit 8 reports CI's five-year historical revenue growth at **5.2%**, above the HVAC OEM average of **2.1%**. Exhibit 2 also shows revenue rising from $4,460 million in 2021 to an estimated $5,060 million in 2022.

3. **The EBITDA gap may be fixable.** CI's recent problem is EBITDA conversion, not demand: five-year historical EBITDA growth is only **1.9% versus 8.4%** for HVAC OEMs, and two-year forward EBITDA growth is **3.3% versus 7.2%**. The case explains that margins declined over the past two years primarily because long-term OEM contracts had infrequent price adjustments. That matters because the underperformance can reverse as contracts reprice.

4. **The plan is burdened for carve-out costs and was diligenced.** Exhibit 3 projects adjusted EBITDA increasing from **$1,046 million in 2023** to **$1,614 million in 2027** and **$1,692 million in 2028**, with margins rising from **22.8% to 27.5%**. The exhibit states that this adjusted EBITDA is already burdened by **$41 million** of incremental standalone costs and quality-of-earnings adjustments. Exhibit 4 records completed finance, tax, HR, operations, IT, cyber, and carve-out diligence, including bottoms-up validation of standalone costs and an identified total cost-savings target. Exhibit 5's bridge to $1,614 million includes regional growth, strategic pricing, SG&A leverage, and cost savings, partly offset by standalone costs, eliminations, and FX.

If that plan is delivered, the entry multiple falls dramatically: $14 billion is only about **8.7x 2027E EBITDA**. This is the source of genuine upside relative to paying an average HVAC multiple for today's EBITDA.

## Risks and caveats

The PF discount should not be treated as guaranteed. The retrieved materials present the PF multiples but do not provide a complete reconciliation of the PF EBITDA bridge. More importantly, the projected EBITDA recovery is back-half weighted and execution-dependent: 2023E EBITDA is below 2022 EBITDA, and the bridge relies on pricing, SG&A leverage, cost initiatives, and favorable offsets. CI's inferior historical and near-term EBITDA growth also means that merely matching the current public-HVAC NTM multiple is not automatically attractive.

The financing structure leaves little room for error. The transaction uses **$5.5 billion of senior debt**, approximately **4.0x leverage**, and a **$2.25 billion, 5% PIK seller note**, plus **$2.0 billion of 7% PIK convertible preferred equity**. This was being negotiated after the Federal Reserve's 75-basis-point rate increases in June and July 2022, and Exhibit 8's own case context notes that an IPO exit would be highly sensitive to broader economic conditions. Expensive leverage does not change the enterprise-value comparison, but it increases the cost of overpaying or missing the EBITDA plan.

## Bottom line

**The $14 billion enterprise value is an attractive entry price relative to public HVAC manufacturers, but only conditionally and moderately so.** On unadjusted current EBITDA it is approximately a market multiple, not a standout discount. It becomes attractive because CI has strong revenue and market positions, its EBITDA weakness has an identifiable contract-pricing explanation, its projections are burdened for standalone costs, and diligence supports the carve-out and cost-reduction plan. 

At the deal table, I would therefore tell ED: **proceed at $14 billion, but treat it as a full-but-reasonable entry dependent on EBITDA recovery—not as a bargain price—and avoid raising the bid unless the recoverable EBITDA is independently verified.**
