# Company CI relative market position

As of 2021, the segment-share exhibit indicates that **Company CI was the leading named competitor in every displayed end market**, although the strength of that position varied materially by segment.

Reading each Company CI block from the exhibit’s 0–100% share axis:

| Segment | Company CI approximate share | Nearest displayed competition | Interpretation |
|---|---:|---|---|
| Residential HVAC | ~70% | LG at ~13%; Rechi ~2%; Other ~15% | Strong, near-dominant position; Company CI is larger than all displayed competitors combined. |
| Product F | ~35% | Company J ~9%; several other named firms and captives; “Other” ~28% | Leading plurality, but the market is fragmented and Company CI is well short of a majority. |
| Refrigeration | ~40% | Companies EN, EV, and BE each ~10%; Other ~30% | Clear leader, but not dominant. |
| Transport | ~40% | Company Z ~20%; Company J ~10%; Other ~30% | Clear leader with a narrower advantage than in Residential HVAC. |

Thus, the exhibit supports describing Company CI as a **scaled, diversified market leader across its major segments**, rather than a niche participant. Its strongest relative position is in **Residential HVAC**, where its approximately 70% share is more than five times the next displayed named competitor. In **Product F, Refrigeration, and Transport**, it still has the largest displayed share—roughly 35–40%—but those positions are plurality positions in more competitive markets.

This is a statement about relative share within each segment only. The exhibit does not, by itself, establish segment sizes, revenue contribution, profitability, growth, or an aggregate company-wide market share. It is also based on approximate stacked-share readings from the chart.
