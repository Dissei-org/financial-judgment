# Diagnosis of Company CI’s recent margin pressure (as of December 2021)

**Diagnosis: Company CI’s recent margin pressure was primarily a temporary contractual pricing lag—not a demand collapse or clear structural erosion.** Long-term contracts with OEM customers contained infrequent price-adjustment provisions, so selling prices did not reset quickly enough when costs rose. As a result, the strong revenue recovery translated into less-than-proportional profit-margin recovery.

## Evidence and interpretation

- Revenue and profit dollars both recovered strongly in 2021, so this was not primarily a volume/demand problem:
  - Revenue increased **18.7%**, from **$3,758m in 2020 to $4,460m in 2021**.
  - Adjusted EBITDA increased **14.7%**, from **$950m to $1,090m**.

- But margins compressed because incremental business came in at lower profitability:
  - Gross margin fell from **34.9% to 33.2%**.
  - Adjusted EBITDA margin fell from **25.3% to 24.4%**.
  - The roughly **$702m** of incremental revenue carried only **$173m** of additional gross profit and **$140m** of additional EBITDA—approximately **24.6%** incremental gross margin and **19.9%** incremental EBITDA margin, below the prior-year company averages.

- The case’s explicit causal explanation is that margins had declined over the prior two years **primarily because long-term OEM contracts had infrequent price-adjustment terms**. This points to delayed cost pass-through/repricing risk rather than permanent competitive loss.
- The pressure was also visible over the longer post-2017 period: gross margin peaked at **37.1%** and adjusted EBITDA margin at **27.3%** in 2017 before falling to **33.2%** and **24.4%** in 2021. Still, the continued growth in 2021 revenue and EBITDA prevents a diagnosis of outright structural failure from the available anchor-date evidence.
- Broad PCE inflation provides context but should not be overstated: the visible series showed **1.4% in 2020 and 1.1% in 2021**. The more company-specific issue was the OEM contract structure and inability to reprice timely.

## Bottom line

At the December 2021 anchor, Company CI should be diagnosed as having **temporary margin compression from a cost/pricing pass-through mismatch under long-term OEM contracts**. The business retained strong demand and profit-dollar growth; the key diligence issue was whether forthcoming contract renewals/price adjustments could restore margins, and how exposed the contract book was before those resets occurred.
