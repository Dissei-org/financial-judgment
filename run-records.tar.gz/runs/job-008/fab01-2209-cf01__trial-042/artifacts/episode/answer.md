# Counterfactual: no Company BR rollover or seller note

## Baseline structure

The proposed transaction used $14,052mm of net funding: a $14,000mm purchase price, $362mm of fees and expenses, less $310mm of cash expected to be generated between signing and closing.

The funding was:

- **$5,500mm** third-party senior debt;
- **$2,250mm** Company BR seller note, 5% PIK;
- **$2,000mm** Company ED/co-invest convertible preferred, 7% PIK;
- **$2,581mm** Company ED/co-invest common equity; and
- **$1,721mm** Company BR rolled common equity.

Thus, Company BR was not merely the seller: it provided **$3,971mm**, or about **28% of total sources**. (The rounded structure table shows this as a $2.25bn note plus a $1.70bn rollover, or roughly $3.95bn.) Company BR had also agreed to provide $50mm of balance-sheet cash, separate from the displayed sources.

## What would have to change to hold the $14bn price

If Company BR refused both the rollover and the note, Company ED would have had to replace the entire **$3.971mm million**—in rounded terms, **$3.95bn / $4.0bn**—of funding gap from some combination of third-party debt and ED/co-invest equity or preferred equity. Mechanically:

1. **Replace the rollover with sponsor common equity.** Company ED/co-invest would have had to contribute the $1,721mm that Company BR would have rolled. Common equity would therefore become 100% ED/co-invest rather than the proposed 60%/40% split.

2. **Replace the seller note.** The $2.25bn could only be closed by (a) more third-party debt, (b) additional convertible preferred, or (c) additional common equity. The like-for-like substitute would be $2.25bn of non-BR junior/subordinated debt plus $1.721bn of additional ED common equity. That would raise ED/co-invest capital from **$4.581bn to $6.302bn**, a **37% increase**.

3. **An all-sponsor-capital solution would require a much larger check.** If ED/co-invest replaced the whole $3.971bn with preferred or common equity while retaining $5.5bn of senior debt, their total contribution would rise from **$4.581bn to $8.552bn**, an **87% increase**. Equity and preferred would then represent about **61% of total sources**, versus about **45%** in the proposed structure.

Simply treating the missing financing as additional senior debt was not a realistic like-for-like fix. The proposed senior debt was already **$5.5bn at approximately 4.0x leverage**. Replacing only the $2.25bn seller note with senior debt would take senior debt to **$7.75bn**, or roughly **5.6x** on the same EBITDA basis. Replacing the entire BR package with senior debt would take it to **$9.47bn**, or roughly **6.9x**, above the proposed first-lien covenant threshold of 6.5x.

Moreover, this was not a normal financing market: non-bank institutional leveraged-loan volume had fallen from **$184bn in 1Q21 to $22bn in 3Q22**, and aggregate quarterly volume had fallen from about **$227bn to $78bn**. The case explicitly says Company ED had to mitigate fundamental risks while overcoming severe scarcity of high-yield debt capital. Consequently, replacement debt would likely have been smaller, more expensive, more discounted, or on tighter terms—not a costless substitute for the BR note.

## Shift in risk sharing

The proposed structure made Company BR share meaningfully in post-closing risk:

- Its **40% common rollover** left it exposed to the first losses in the business and to carve-out execution, standalone-cost, growth, and exit risks.
- Its **$2.25bn seller note** deferred consideration and gave it credit exposure to the new company. The note’s 5% PIK feature also reduced near-term cash pressure in exchange for that continued risk.
- Together, those instruments gave Company BR an economic reason to cooperate on the carve-out, TSAs, personnel transition, and value-creation plan.
- The converted ED preferred also had priority sell-down ahead of common after an IPO, so BR’s 40% common position was tied to the residual exit outcome.

Without them, Company BR would become a substantially cash-paid seller with no remaining ownership or seller-note exposure. The risk would shift as follows:

- **Company ED/co-investors would take the residual business risk alone.** Common ownership would move from the proposed 60% ED / 40% BR split to 100% ED/co-invest, and ED’s capital at risk would rise materially.
- **If debt replaced the note, lenders and the business would bear more financial risk.** Even junior third-party debt substituted for BR’s 5% PIK note would leave nominal debt similar but increase external, contractual debt and likely carry less flexible terms. The company would have greater sensitivity to EBITDA shortfalls, refinancing, and rising SOFR-based interest costs. In the extreme all-senior-debt case, leverage would move from roughly 4.0x toward roughly 6.9x.
- **If more preferred equity replaced the note, ED/co-investors would still absorb the added risk.** Additional 7% PIK preferred would avoid leverage but increase accrued claims, conversion dilution, and the sponsor check; moving $2.25bn from a 5% PIK note to 7% PIK preferred would add about $45mm of annual PIK accrual before compounding.
- **Alignment would weaken.** Company BR would have less economic incentive to stand behind forecasts, transition services, cost savings, and carve-out execution; ED and its co-investors would no longer have the seller’s “skin in the game.”

In short, closing at the same price without Company BR would have required either a materially larger ED/co-invest equity or preferred check, or materially more—and probably more expensive—third-party debt. The former concentrated business risk almost entirely on ED/co-investors; the latter added financial risk and shifted more downside risk to the operating company and its lenders. What disappeared would be the proposed structure’s substantial seller risk-sharing and alignment benefit.
