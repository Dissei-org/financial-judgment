# Would Company CI be relatively resilient if demand weakened after 2021-12?

**Short answer: Yes — relatively resilient in earnings and margins, though not immune on revenue.** The case materials available at the anchor (Exhibits 1 and 2) support a view that CI is a cyclical-but-defensive business: its top line moves with end-market demand, but its margins and EBITDA have historically held up far better than revenue, and it enters any downturn from a position of dominant market share.

## 1. Track record through prior downturns (Exhibit 2, 2007A–2021A)

The dataroom gives 15 years of financials, which cover two demand shocks:

| Downturn | Revenue | Adj. EBITDA | Gross margin | EBITDA margin |
|---|---|---|---|---|
| 2009 (GFC) | $3,449m → $2,921m (**-15.3%**) | $740m → $650m (**-12.2%**) | 28.4% → **29.7%** (up) | 21.5% → **22.3%** (up) |
| 2020 (COVID) | $4,068m → $3,758m (**-7.6%**) | $1,010m → $950m (**-5.9%**) | 33.9% → **34.9%** (up) | 24.8% → **25.3%** (up) |

Key observations:
- **EBITDA fell less than revenue in both downturns** and margins actually *expanded*. That is the signature of a flexible cost base (variable COGS, ability to take cost out quickly) rather than a high-fixed-cost, operationally levered manufacturer.
- **Business stayed solidly profitable at trough.** Even in 2009, the worst year in the series, CI generated $650m of Adj. EBITDA at a 22% margin — never close to break-even.
- **Fast recovery.** Revenue rebounded +18.6% in 2010 and +18.7% in 2021; EBITDA rebounded +39.5% and +14.7%. Each recovery took EBITDA to a new high above the prior peak ($907m in 2010 vs $740m pre-GFC; $1,090m in 2021 vs $1,086m in 2018).
- **Structural margin improvement.** EBITDA margin has moved from ~21% (2007–09) to a 24–27% band since 2010, and gross margin from ~28% to 33–37%. The floor is higher now than it was going into the last major recession.
- **Low volatility in normal years.** Outside the two shocks, annual revenue changes were within roughly -6% to +7%, and EBITDA was within a $885m–$1,090m band from 2011–2021 — a narrow range for an 11-year period.

## 2. Competitive position going into a downturn (Exhibit 1)

CI holds leading share in every segment shown:
- **Residential HVAC compressors: ~70%** (next largest, LG, ~13%; Rechi ~2%).
- **Product F: ~35%** (largest; nearest competitors 5–9% each, plus ~10% captive).
- **Refrigeration: ~40%** (next ~10% each).
- **Transport: ~40%** (Company Z ~20%, Company J ~10%).

Scale leadership matters in a downturn: it supports pricing discipline, purchasing leverage on materials, and the ability to absorb fixed costs across a large installed base. A 70% share in residential HVAC also implies CI's demand is tied to the broad replacement cycle of the installed base (failed compressors get replaced regardless of the economy), which tends to cushion the most cyclical new-construction component.

## 3. Caveats — where resilience is limited

- **Revenue is clearly cyclical.** A -15% top-line hit in 2009 is meaningful; CI is not a recurring-revenue business. Residential HVAC and refrigeration/transport are tied to housing, consumer and industrial capex.
- **2021 margins are already down.** EBITDA margin slipped to 24.4% in 2021 (from 27.3% in 2017) and gross margin to 33.2% despite record revenue, suggesting input-cost / supply-chain pressure at the anchor. A downturn starting from a compressed margin base gives less cushion than 2017–18 would have.
- **The 2021 base is inflated by a rebound.** Revenue of $4,460m is +18.7% on a depressed 2020; some normalization is plausible even without a recession.
- **Leverage context (Exhibit 9, timeline).** The leveraged loan market hit record issuance in 1Q21 ($228bn incl. pro-rata) and a carve-out buyer would likely load the asset with debt. Resilience of the *business* does not equal resilience of an *LBO equity stake* — the same ~12% EBITDA decline is far more painful at 6–7x leverage. Inflation was low through 2021 (PCE 1.1–2.4%, Exhibit 6), so rate pressure was not yet in the base case, but it is a risk to the financing structure rather than the operations.
- Limited qualitative disclosure: the only primary source visible at the anchor is a leadership page, so there is no management commentary on cost flexibility, backlog, or aftermarket mix to corroborate the numbers.

## Conclusion

Based on the anchor-date evidence, I would expect Company CI to be **relatively resilient**: in the two prior demand shocks its EBITDA declined only ~6–12% versus revenue declines of ~8–15%, margins expanded rather than contracted, the business stayed highly profitable at trough, and it recovered to new peaks within a year. Its dominant share (70% in residential HVAC, ~35–40% elsewhere) and the replacement-driven nature of compressor demand underpin that. The appropriate framing is "cyclical revenue, defensive earnings" — resilient for an industrial, but a buyer should size leverage assuming a 10–15% EBITDA drawdown is possible, and should note that 2021 margins are already below the 2016–18 peak.
