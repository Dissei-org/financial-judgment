# Is $14bn for Company CI attractive versus public HVAC comps? (as of Sept 2022)

## Bottom line
**No, not on a reported basis. The $14bn entry price is roughly at parity with where public HVAC OEMs trade today, and only looks cheap on a pro forma basis that capitalizes cost savings Company ED has not yet delivered.** The price is fair-to-full for an asset with a weaker growth and margin trajectory than the public peer set. Returns in this deal must come from executing the operational bridge (and hoping public multiples mean-revert), not from buying at a discount.

## 1. What $14bn implies (Exhibit 8, Exhibit 2, Exhibit 3, Exhibit 5)
- Exhibit 8 states that at a $14bn purchase price, Company CI is valued at **12.4x LTM / 13.4x NTM EBITDA** (reported) and **10.4x / 11.3x pro forma (PF)**; on EBIT, 14.7x / 15.8x reported and 11.9x / 13.0x PF. Multiples are centered on FYE 9/30/22.
- Cross-check: $14,000mm / 12.4x = ~$1,130mm LTM EBITDA, which ties to the 2022 EBITDA of $1,130mm in the Exhibit 5 bridge (Exhibit 2's 2022E Adj. EBITDA of $1,175mm less the ~$41mm standalone/QoE burden noted in Exhibit 3). $14,000mm / 13.4x = ~$1,045mm, which ties to 2023E Adj. EBITDA of $1,046mm in Exhibit 3. So the reported multiples are on stand-alone, carve-out-burdened earnings.
- The PF multiples imply EBITDA of ~$1,346mm (LTM) / ~$1,239mm (NTM), i.e. ~$200-220mm of credit for run-rate improvements. That is essentially the Exhibit 5 bridge items "Cost Savings Initiatives" ($148mm) + "SG&A Leverage" ($72mm) = $220mm, which are 2022-2027 targets, not current earnings. Exhibit 4 confirms the operational work is at the stage of an "identified total cost-savings target" - identified, not realized.

## 2. Comparison to public HVAC OEMs (Exhibit 8)
| Metric | Company CI @ $14bn (reported / PF) | HVAC OEMs current | HVAC OEMs 5-yr avg | HVAC OEMs 10-yr avg |
|---|---|---|---|---|
| EV/LTM EBITDA | 12.4x / 10.4x | 12.9x | - | - |
| EV/NTM EBITDA | 13.4x / 11.3x | 13.2x | 14.4x | 13.5x |
| EV/LTM EBIT | 14.7x / 11.9x | 16.2x | - | - |
| EV/NTM EBIT | 15.8x / 13.0x | 15.2x | 16.8x | 15.6x |

- **Reported LTM:** 12.4x vs 12.9x - a discount of only ~0.5 turns (~4%).
- **Reported NTM:** 13.4x vs 13.2x - Company ED is actually paying a *slight premium* to current public OEM multiples on forward earnings, because CI's NTM EBITDA steps down (2022: $1,130mm -> 2023E: $1,046mm) as standalone costs, eliminations and FX hit. NTM EBIT tells the same story (15.8x vs 15.2x).
- **Versus history:** Public HVAC OEMs have de-rated from a 5-yr average of 14.4x NTM to 13.2x today, consistent with the rate shock (Fed hiking 75bp in June, July and again in September 2022 - Source 4; timeline). CI's 13.4x NTM is ~1 turn below the peers' 5-yr average and roughly equal to the 10-yr average (13.5x). So the price is in line with a *normal* HVAC multiple, not a trough one.
- **Only on PF** (10.4x / 11.3x) does CI look 2-2.5 turns cheap versus current OEMs and ~3 turns cheap versus the 5-yr average - but that discount is entirely manufactured by capitalizing unrealized savings at the full peer multiple.

## 3. Why parity is not attractive: CI deserves a discount to the OEM set (Exhibit 8, Exhibit 2)
- **Growth:** CI's 5-yr historical EBITDA growth is 1.9% vs 8.4% for HVAC OEMs; 2-yr forward EBITDA growth is 3.3% vs 7.2%. Revenue growth (5.2% vs 2.1%) is better, but CI has not converted it into earnings.
- **Margins are compressing:** Exhibit 2 shows Adj. EBITDA margin falling from a 27.3% peak (2017) to 24.4% (2021) and 23.2% (2022E); gross margin from 37.1% to 31.1%. The case attributes this to long-term OEM contracts with infrequent price adjustments. 2023E margin (Exhibit 3) is 22.8%, lower still.
- **Cyclicality:** Exhibit 2 shows revenue drops of -15.3% (2009) and -7.6% (2020), and EBITDA declines in 2009, 2012, 2015, 2019 and 2020 - relevant when the Fed is explicitly weighing recession risk to tame inflation (Source 5, Sept 2022).
- Paying the same multiple as peers growing EBITDA 2-4x faster with stable margins is, on a growth-adjusted basis, paying a **premium**, not a discount.
- The "Comparable Margin Industrials" set (19.0x LTM / 15.3x NTM, 5-yr avg 16.4x) is not the right anchor: those companies grow 2-yr forward EBITDA at 15.7% vs CI's 3.3%.

## 4. Mitigating points (why the price is defensible, if not cheap)
- CI is the clear leader in its markets (Exhibit 1: ~70% share in residential HVAC compressors, ~35-40% in the other three segments), which supports a full multiple.
- Exhibit 5's bridge takes EBITDA from $1,130mm to $1,614mm by 2027E (27.5% margin, Exhibit 3). If delivered, the effective entry multiple on 2027E EBITDA is ~8.7x, and the public 5-yr average NTM multiple of 14.4x offers ~1 turn of potential re-rating at exit - i.e. the return thesis is operational improvement plus mean-reversion, not entry discount.
- Deal structure softens the headline price: Company BR rolls 40% of the common ($1.70bn) and takes a $2.25bn 5% PIK seller note (table_1, Exhibit 10), so ED's cash-at-risk is well below $14bn EV, and diligence is complete with TSAs in place (Exhibit 4).

## 5. Conclusion
Measured strictly against public HVAC manufacturers, $14bn is **not an attractive entry price - it is a market price.** On reported earnings it is 12.4x LTM (0.5x below peers) and 13.4x NTM (0.2x above peers), for a business growing EBITDA at less than half the peer rate with four years of margin erosion. The apparent 2-3 turn discount exists only on pro forma numbers that give Company ED full credit today for ~$220mm of savings it still has to earn. The deal team should therefore not present the transaction as buying cheaply versus comps; it should underwrite it as a fairly-priced, control-based operational turnaround where value creation depends on realizing the Exhibit 5 bridge and on the public OEM multiple recovering from today's rate-compressed 13.2x toward its 14.4x five-year average - both of which are execution and market risks, not entry-price cushions.
