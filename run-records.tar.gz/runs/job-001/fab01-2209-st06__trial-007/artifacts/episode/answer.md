# Gating diligence workstream for Company ED before signing the Company CI carve-out (as of Sept 2022)

## Answer: the Carve-Out / separation (standalone-cost, TSA and stand-up) workstream should be gating.

### 1. It is the only workstream that is not actually finished
Exhibit 4 (Company CI diligence progress report) lists six workstreams. Five are reported in closed, past-tense language:
- Finance/Accounting (Company BT): "diligence complete", modest QoE adjustment, lockbox mechanics finalized.
- Tax (Company BT / Subsidiary P): "Tax diligence completed", structuring co-developed.
- HR (Company BT / Company ED): pension, unions/labor, exec comp, HR capabilities review "completed".
- Operations (Company EJ / Company ED): multi-month study "completed", cost-savings target identified.
- IT & Cyber (PwC / Company ED): "complete".

The Carve-Out workstream (Company EJ / Company ED) is described differently: "detailed bottoms-up work to validate management standalone cost assumptions", "identified specific personnel moving", "TSAs well in-place and roadmap established to fully stand-up functions". That is a description of work in flight and of a plan, not of a validated result. It never says the standalone cost base is confirmed, that TSA schedules/pricing/durations are executed, or that the stand-up roadmap has been costed. Because it is the one open item, it is by definition the item that should gate signing.

### 2. Standalone-cost accuracy is the single biggest swing factor in the case economics
The numbers in the dataroom are internally inconsistent on exactly this point:
- Exhibit 5 (2022-2027 EBITDA bridge) carries "Standalone Costs" at only -$6m (about -1% of the growth bridge).
- Exhibit 3 (projections) says Adj. EBITDA is "burdened for $41mm of incremental standalone costs and QoE adjustments not reflected in historical financials".
- The same Exhibit 3 shows a separate line for "Minority Interest / Stand-up Costs / One-time Expenses" of -$102m (2023E), -$98m, -$77m, -$81m, -$82m, -$84m - roughly $80-100m of cash every year through 2028, i.e. the largest cash drag after capex.
- Exhibit 5 also carries "Incremental Elims / Other" at -$68m, which signals ongoing intercompany dependencies with Company BR (Company BR keeps 40% of the common and is a captive-type customer/supplier; Exhibit 1 shows Company CI at ~70% share of residential HVAC compressors and 35-40% in Product F, refrigeration and transport).

Until the carve-out workstream reconciles $6m vs $41m vs ~$100m/yr, Company ED does not actually know the earnings and cash base it is buying.

### 3. The capital structure leaves no room for a standalone-cost miss
Exhibit table_1 / Exhibit 10: $14.0bn purchase price (12.4x LTM, 10.4x pro forma for cost savings per Exhibit 8), funded with:
- $5.5bn third-party senior debt ($2.9bn TLA at SOFR+4.50% stepping up 50bp/yr from year 3, 97.5 OID; $2.6bn direct loan at SOFR+6.75%, 96.6 OID) with a 1st-lien net leverage covenant of 6.5x;
- $2.25bn seller note at 5% PIK; $2.0bn convertible preferred at 7% PIK; $2.55bn Company ED/co-invest common; $1.7bn Company BR common; only $50m cash on balance sheet.

Against 2022 EBITDA of ~$1,130-1,175m (Exhibits 2 and 5) and 2023E EBITDA of $1,046m (Exhibit 3), the $5.5bn senior debt alone is ~4.9-5.3x, and total debt-like capital (~$9.75bn) is ~9x 2023E EBITDA. With 30-day SOFR at 2.42% on 9/30/22 and the Fed having just delivered another 75bp hike (Source 4) and signalling more, cash interest on the third-party debt is already ~$440m+/yr and rising, on top of $370m of 2023E capex and ~$100m of stand-up costs. 2023E free cash flow is close to zero. A $50-100m error in standalone costs is therefore not a valuation nuance; it is the difference between covenant headroom and a covenant problem in year one.

### 4. The value-creation plan itself depends on a clean separation
Of the $484m of EBITDA growth in the bridge, $148m (31%) is cost-savings initiatives and $72m (15%) is SG&A leverage; a further $105m (22%) is strategic pricing. The Operations workstream has "identified" the savings target, but realizing it requires the functions to be fully stood up outside Company BR on schedule - the very thing the carve-out roadmap has to prove. Exhibit 3 already shows revenue falling ~9% in 2023E ($5,060m to $4,590m) and margin compressing to 22.8%, in a cyclical business (revenue -15% in 2009, -8% in 2020) with recession risk flagged in Source 5. The plan has no cushion if separation costs run over or TSAs extend.

### 5. Why the other workstreams should not control the go/no-go
- Finance/Tax/HR/IT/Operations are reported complete with only a "modest" QoE adjustment; residual risk there is known and priced.
- Financing terms are already negotiated and macro (rates, inflation, leveraged-loan volume collapsing from $184bn in 1Q21 to $22bn institutional in 3Q22 per Exhibit 9) is a market judgement, not a diligence deliverable - it argues for caution but cannot be "completed" by more work.
- Valuation is a decision that sits downstream of the standalone cost base; you cannot judge 12.4x/10.4x pro forma until the pro forma EBITDA is real.

### Recommendation
Treat Carve-Out/separation diligence as a condition precedent to signing. Before Persons BG, BL and BB sign off, Company ED should require: (i) a completed bottoms-up standalone cost model reconciled to the $6m / $41m / ~$100m per year figures; (ii) executed TSA schedules with scope, pricing, duration and exit milestones; (iii) the personnel transfer list and any retention/pension costs tied to HR findings; (iv) long-term supply/commercial agreements with Company BR covering the intercompany volumes behind the -$68m elims line; and (v) a covenant sensitivity showing 1st-lien net leverage against a $50-100m standalone-cost overrun and a 2009/2020-style downturn. If Company BR will not underwrite the standalone cost estimate (e.g. via TSA cost caps, purchase price adjustment or seller-note terms), the gap should be reflected in price or the deal should not be signed in September 2022.
