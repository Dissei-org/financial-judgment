# Company CI relative market position — inference from the segment-share exhibit (as of 2022-06)

## Bottom line
Exhibit 1 ("Company CI (as of 2021)", source: company documents) implies that Company CI is the **#1 player in every one of its four end-market segments**, and in most of them by a wide margin over the next-largest competitor. The exhibit points to a scaled, entrenched market leader — the kind of position that normally carries pricing power, scale economies and customer stickiness — rather than a fragmented, share-taking challenger.

## Evidence from Exhibit 1 (share bands read as approximate % of segment)
| Segment | Company CI share | Next competitor(s) | CI lead vs. #2 |
|---|---|---|---|
| Residential HVAC | ~70% | LG ~13%, Rechi ~2%, Other ~15% | ~5x the #2 player; near-dominant |
| Product F | ~35% | Company EN ~5%, Company EU ~7%, Company FA ~6%, Company J ~9%, Other Captive ~10%, Other ~28% | ~4x the largest named competitor; #1 in a segment where a meaningful slice (~10%) is captive/in-house supply |
| Refrigeration | ~40% | Company EN ~10%, Company EV ~10%, Company BE ~10%, Other ~30% | 4x each of three roughly equal #2s |
| Transport | ~40% | Company Z ~20%, Company J ~10%, Other ~30% | 2x the #2 — the most contested segment |

## What this implies
1. **Clear category leadership across the portfolio.** CI leads all four segments; no rival is #1 anywhere. Share is not concentrated in a single niche — leadership is broad-based, which diversifies the position.
2. **Very large share gaps.** In Residential HVAC (~70%) CI is roughly five times LG, the only other scaled competitor; in Product F and Refrigeration CI is ~4x the next player. These are structures where the leader typically sets price and enjoys the best unit economics (purchasing scale, R&D amortisation, installed base/aftermarket).
3. **Transport is the relatively weakest position.** CI still leads (~40%) but Company Z at ~20% is a credible #2 — this is where competitive pressure on share/price is most plausible.
4. **Fragmented tail and captive supply.** The 'Other' buckets (15–30%) and the ~10% captive share in Product F suggest a long tail of smaller/in-house suppliers rather than a consolidated rival; that is generally favourable for the leader, though captive supply in Product F caps the addressable market somewhat.

## Corroboration from Exhibit 2 (financials, 2007A–2021A)
The financial profile is consistent with a leadership position: gross margin expanded from ~28% (2007) to a 33–37% range since 2010 and Adj. EBITDA margin has held ~24–27% for over a decade, including through the 2009, 2015–16, 2019 and 2020 downturns (revenue fell but EBITDA margin stayed ≥22%). Stable margins through cycles are what one would expect from a scaled leader with pricing power, not from a sub-scale competitor. Revenue rebounded +18.7% in 2021 to $4.46bn with $1.09bn Adj. EBITDA.

## Caveats
- The exhibit gives approximate share bands from company documents (management's own framing of segment definitions); segment scope and geography are not specified, so the absolute numbers should be treated as directional.
- Shares are a snapshot as of 2021 — the exhibit says nothing about share trend (gaining vs. losing), and nothing after 2022-06 can be assumed.
- Leadership does not eliminate cyclicality: Exhibit 2 shows revenue is clearly cyclical (-15% in 2009, -7.6% in 2020), so the strong position mitigates margin risk more than volume risk.

## Conclusion
The segment-share exhibit implies Company CI is the dominant, #1 competitor in each of its four segments (roughly 70/35/40/40% share) with the nearest rival typically holding a quarter or less of CI's share; Transport (Company Z at ~20%) is the only segment with a scaled challenger. Combined with the stable ~25% EBITDA margins in Exhibit 2, this supports viewing CI as a scaled market leader with durable pricing power — a key underwriting point for a 2022 carve-out buyer.
